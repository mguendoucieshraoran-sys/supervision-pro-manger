import os, traceback
from datetime import datetime, date, timedelta, time
from flask import Flask, render_template, request, redirect, url_for, session, flash, jsonify
from flask_sqlalchemy import SQLAlchemy
from sqlalchemy import text
from werkzeug.security import generate_password_hash, check_password_hash
try:
    from fpdf import FPDF
except ImportError:
    try:
        from fpdf2 import FPDF
    except ImportError:
        FPDF = None

app = Flask(__name__)
app.secret_key = 'supervision_pro_secure_2026'

# --- CONFIGURATION LOCALE ---
basedir = os.path.abspath(os.path.dirname(__file__))
instance_path = os.path.join(basedir, 'instance')
os.makedirs(instance_path, exist_ok=True)

app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///' + os.path.join(instance_path, 'supervision.db')
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
db = SQLAlchemy(app)

# Dossiers
for folder in ['static/reports', 'static/audio', 'templates']:
    os.makedirs(os.path.join(basedir, folder), exist_ok=True)

# --- MODÈLES ---
class Company(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(100), unique=True)
    code = db.Column(db.String(20), unique=True) # Code unique pour la société (ex: MELEK01)
    last_report_sent = db.Column(db.Date, nullable=True)
    created_at = db.Column(db.DateTime, default=datetime.now)

class Server(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    company_id = db.Column(db.Integer, db.ForeignKey('company.id'), default=1)
    name = db.Column(db.String(100)) # Removed unique=True to allow same name in different companies
    password_hash = db.Column(db.String(200))
    department = db.Column(db.String(50), default='restauration')
    hbg_role = db.Column(db.String(20), default='none') # none, responsable, superviseur
    company = db.relationship('Company', backref='servers')

class Manager(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    company_id = db.Column(db.Integer, db.ForeignKey('company.id'), default=1)
    username = db.Column(db.String(100), default='admin')
    email = db.Column(db.String(120), nullable=True)
    password_hash = db.Column(db.String(200))
    company = db.relationship('Company', backref='managers')

class WeeklyPlan(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    company_id = db.Column(db.Integer, db.ForeignKey('company.id'), default=1)
    server_id = db.Column(db.Integer)
    year = db.Column(db.Integer); week = db.Column(db.Integer); day_of_week = db.Column(db.Integer)
    start_time_str = db.Column(db.String(5), default="08:00")
    end_time_str = db.Column(db.String(5), default="16:00")
    duration_minutes = db.Column(db.Integer, default=480)
    is_off = db.Column(db.Boolean, default=False)

class Shift(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    company_id = db.Column(db.Integer, db.ForeignKey('company.id'), default=1)
    server_id = db.Column(db.Integer, db.ForeignKey('server.id'))
    date_str = db.Column(db.String(10))
    actual_start_time = db.Column(db.DateTime)
    actual_end_time = db.Column(db.DateTime, nullable=True)
    lateness_minutes = db.Column(db.Integer, default=0)
    overtime_minutes = db.Column(db.Integer, default=0)
    server = db.relationship('Server', backref='shifts')

class Task(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    company_id = db.Column(db.Integer, db.ForeignKey('company.id'), default=1)
    phase = db.Column(db.String(50)) # Avant / Pendant / Après
    name = db.Column(db.String(200))
    scheduled_time = db.Column(db.String(100), default="")
    required_people = db.Column(db.Integer, default=1)
    department = db.Column(db.String(50), default='restauration')
    assigned_server_id = db.Column(db.Integer, nullable=True) # Nouveau : Assigner à un serveur précis

class TaskStatus(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    company_id = db.Column(db.Integer, db.ForeignKey('company.id'), default=1)
    server_id = db.Column(db.Integer)
    task_id = db.Column(db.Integer)
    date_str = db.Column(db.String(10))
    is_done = db.Column(db.Boolean, default=False)
    completion_time = db.Column(db.DateTime, nullable=True)

class StockItem(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    company_id = db.Column(db.Integer, db.ForeignKey('company.id'), default=1)
    name = db.Column(db.String(100))
    current_quantity = db.Column(db.Integer, default=0)
    min_threshold = db.Column(db.Integer, default=5)
    department = db.Column(db.String(50), default='restauration')

class StockTransaction(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    item_id = db.Column(db.Integer, db.ForeignKey('stock_item.id'))
    quantity = db.Column(db.Integer)
    type = db.Column(db.String(10)) # IN / OUT
    timestamp = db.Column(db.DateTime, default=datetime.now)
    shift_id = db.Column(db.Integer, nullable=True)
    item = db.relationship('StockItem', backref='transactions')

class ShiftStock(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    company_id = db.Column(db.Integer, db.ForeignKey('company.id'), default=1)
    shift_id = db.Column(db.Integer)
    item_id = db.Column(db.Integer)
    init = db.Column(db.Integer, default=0) # Stock au début du shift
    sales = db.Column(db.Integer, default=0) # Quantité vendue/sortie
    rem = db.Column(db.Integer, default=0) # Reste à la fin du shift
    item = db.relationship('StockItem', primaryjoin="ShiftStock.item_id==StockItem.id", foreign_keys="ShiftStock.item_id")

class Message(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    company_id = db.Column(db.Integer, db.ForeignKey('company.id'), default=1)
    server_id = db.Column(db.Integer, nullable=True) # Null = broadcast or manager recipient
    sender_id = db.Column(db.Integer, nullable=True) # ID of sender (Server ID or 0 for Manager)
    content = db.Column(db.String(500))
    image_path = db.Column(db.String(200), nullable=True)
    audio_path = db.Column(db.String(200), nullable=True)
    timestamp = db.Column(db.DateTime, default=datetime.now)
    is_read = db.Column(db.Boolean, default=False)

class EmailConfig(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    company_id = db.Column(db.Integer, db.ForeignKey('company.id'), default=1)
    smtp_server = db.Column(db.String(100))
    smtp_port = db.Column(db.Integer, default=587)
    sender_email = db.Column(db.String(100))
    password = db.Column(db.String(100))
    recipient_email = db.Column(db.String(100))

# --- MODÈLE ÉVÉNEMENT (Fiche de Fonction) ---
class Event(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    company_id = db.Column(db.Integer, db.ForeignKey('company.id'), default=1)
    title = db.Column(db.String(200))
    event_date = db.Column(db.String(10))  # YYYY-MM-DD
    event_time = db.Column(db.String(5), default='12:00')
    guest_count = db.Column(db.Integer, default=0)
    menu_details = db.Column(db.Text, default='')
    equipment_details = db.Column(db.Text, default='')
    notes = db.Column(db.Text, default='')
    created_at = db.Column(db.DateTime, default=datetime.now)
    is_archived = db.Column(db.Boolean, default=False)
    department = db.Column(db.String(50), default='restauration')

class EventTask(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    event_id = db.Column(db.Integer, db.ForeignKey('event.id'))
    server_id = db.Column(db.Integer, db.ForeignKey('server.id'))
    description = db.Column(db.String(300))
    is_done = db.Column(db.Boolean, default=False)

# --- MODÈLES HÉBERGEMENT ---
class HbgInspection(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    company_id = db.Column(db.Integer, db.ForeignKey('company.id'), default=1)
    location = db.Column(db.String(200)) # Chambre, étage...
    status = db.Column(db.String(100)) # Propre, à revoir...
    created_at = db.Column(db.DateTime, default=datetime.now)

class HbgFollowUp(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    company_id = db.Column(db.Integer, db.ForeignKey('company.id'), default=1)
    location = db.Column(db.String(200))
    items_to_inspect = db.Column(db.Text) # Grande case texte
    is_ok = db.Column(db.Boolean, default=True) # Oui/Non (True=Oui)
    responsible_name = db.Column(db.String(100))
    progress_percent = db.Column(db.Integer, default=0) # Pourcentage (0 par défaut)
    created_at = db.Column(db.DateTime, default=datetime.now)

# --- NOUVEAUX MODÈLES TABLEAUX DYNAMIQUES HÉBERGEMENT ---
class HbgTable(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    company_id = db.Column(db.Integer, db.ForeignKey('company.id'), default=1)
    name = db.Column(db.String(100))
    table_type = db.Column(db.String(50), default='inspection') # 'inspection' ou 'followup'
    created_at = db.Column(db.DateTime, default=datetime.now)

class HbgColumn(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    table_id = db.Column(db.Integer, db.ForeignKey('hbg_table.id'))
    label = db.Column(db.String(100))
    order = db.Column(db.Integer, default=0)

class HbgRow(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    table_id = db.Column(db.Integer, db.ForeignKey('hbg_table.id'))
    label = db.Column(db.String(100))
    order = db.Column(db.Integer, default=0)

class HbgCell(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    row_id = db.Column(db.Integer, db.ForeignKey('hbg_row.id'))
    col_id = db.Column(db.Integer, db.ForeignKey('hbg_column.id'))
    value = db.Column(db.String(200), default='')
    updated_at = db.Column(db.DateTime, default=datetime.now, onupdate=datetime.now)

class SaleRecord(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    shift_id = db.Column(db.Integer, db.ForeignKey('shift.id'))
    item_id = db.Column(db.Integer, db.ForeignKey('stock_item.id'))
    quantity = db.Column(db.Integer, default=1)
    timestamp = db.Column(db.DateTime, default=datetime.now)
    item = db.relationship('StockItem')
    shift = db.relationship('Shift')

# --- PDF ---
def clean_str(s):
    if not s: return ""
    return str(s).replace('\n', ' ').encode('latin-1', 'replace').decode('latin-1')

def generate_pdf(sh_id):
    if not FPDF:
        return None
    try:
        sh = Shift.query.get(sh_id)
        if not sh: return None
        srv = Server.query.get(sh.server_id)
        if not srv: return None
        
        pdf = FPDF()
        pdf.add_page()
        
        # ===== EN-TÊTE =====
        pdf.set_fill_color(33, 37, 41)  # Fond sombre
        pdf.set_text_color(255, 255, 255)
        pdf.set_font("Arial", 'B', 18)
        pdf.cell(190, 15, txt=clean_str(f"RAPPORT DE SERVICE"), border='B', ln=True, align='C', fill=True)
        pdf.set_font("Arial", 'B', 12)
        pdf.cell(190, 10, txt=clean_str(f"{srv.name.upper()} - {sh.date_str}"), border='B', ln=True, align='C', fill=True)
        pdf.set_text_color(0, 0, 0)
        pdf.ln(8)
        
        # ===== TABLEAU 1 : INFORMATIONS DU SERVICE =====
        pdf.set_font("Arial", 'B', 12)
        pdf.set_fill_color(0, 123, 255)
        pdf.set_text_color(255, 255, 255)
        pdf.cell(190, 9, "  HORAIRES DU SERVICE", ln=True, fill=True)
        pdf.set_text_color(0, 0, 0)
        
        # En-tête
        pdf.set_font("Arial", 'B', 9)
        pdf.set_fill_color(240, 240, 240)
        col_w = 47.5
        headers_h = ["Heure Debut", "Heure Fin", "Retard (min)", "Heures Sup (min)"]
        for h in headers_h:
            pdf.cell(col_w, 8, h, 1, 0, 'C', True)
        pdf.ln()
        
        # Données
        pdf.set_font("Arial", '', 10)
        start_t = sh.actual_start_time.strftime('%H:%M') if sh.actual_start_time else '--:--'
        end_t = sh.actual_end_time.strftime('%H:%M') if sh.actual_end_time else 'En cours'
        pdf.cell(col_w, 9, start_t, 1, 0, 'C')
        pdf.cell(col_w, 9, end_t, 1, 0, 'C')
        pdf.cell(col_w, 9, str(sh.lateness_minutes), 1, 0, 'C')
        pdf.cell(col_w, 9, str(sh.overtime_minutes), 1, 0, 'C')
        pdf.ln()
        
        # Durée totale
        if sh.actual_start_time and sh.actual_end_time:
            dur = int((sh.actual_end_time - sh.actual_start_time).total_seconds() / 60)
            pdf.set_font("Arial", 'I', 9)
            pdf.cell(190, 7, f"Duree totale : {dur // 60}h{dur % 60:02d}", 0, 1, 'R')
        pdf.ln(5)
        
        # ===== TABLEAU 2 : CHECKLIST DES TÂCHES =====
        pdf.set_font("Arial", 'B', 12)
        pdf.set_fill_color(40, 167, 69)
        pdf.set_text_color(255, 255, 255)
        pdf.cell(190, 9, "  CHECKLIST DES TACHES", ln=True, fill=True)
        pdf.set_text_color(0, 0, 0)
        
        # En-tête
        pdf.set_font("Arial", 'B', 9)
        pdf.set_fill_color(240, 240, 240)
        pdf.cell(80, 8, "Tache", 1, 0, 'L', True)
        pdf.cell(30, 8, "Heure Prev.", 1, 0, 'C', True)
        pdf.cell(30, 8, "Nb Pers.", 1, 0, 'C', True)
        pdf.cell(25, 8, "Statut", 1, 0, 'C', True)
        pdf.cell(25, 8, "Fait a", 1, 0, 'C', True)
        pdf.ln()
        
        # Groupement par phase (sécurisé)
        t_by_p = {"Avant le service": [], "Pendant le service": [], "Après le service": []}
        statuses = TaskStatus.query.filter_by(server_id=sh.server_id, date_str=sh.date_str).all()
        done_count = 0
        for st in statuses:
            t = Task.query.get(st.task_id)
            if t:
                ph = t.phase if t.phase in t_by_p else "Pendant le service"
                t_by_p[ph].append({'task': t, 'status': st})
                if st.is_done: done_count += 1
        
        pdf.set_font("Arial", '', 9)
        for phase, items in t_by_p.items():
            if not items: continue
            pdf.set_font("Arial", 'B', 10)
            pdf.set_fill_color(245, 245, 245)
            pdf.cell(190, 8, clean_str(f"--- {phase.upper()} ---"), 1, 1, 'C', True)
            pdf.set_font("Arial", '', 9)
            for item in items:
                t = item['task']
                st = item['status']
                status_txt = "FAIT" if st.is_done else "NON FAIT"
                time_done = st.completion_time.strftime('%H:%M') if st.completion_time else "--"
                pdf.cell(80, 7, clean_str(f"  {t.name}"), 1)
                pdf.cell(30, 7, str(t.scheduled_time), 1, 0, 'C')
                pdf.cell(30, 7, str(t.required_people), 1, 0, 'C')
                pdf.cell(25, 7, status_txt, 1, 0, 'C')
                pdf.cell(25, 7, time_done, 1, 0, 'C')
                pdf.ln()
        
        # Résumé tâches
        total_tasks = len(statuses)
        pdf.set_font("Arial", 'B', 9)
        pdf.cell(190, 7, f"Total : {done_count}/{total_tasks} taches completees", 0, 1, 'R')
        pdf.ln(5)
        
        # ===== TABLEAU 3 : INVENTAIRE DES STOCKS =====
        pdf.set_font("Arial", 'B', 12)
        pdf.set_fill_color(255, 193, 7)
        pdf.set_text_color(0, 0, 0)
        pdf.cell(190, 9, "  INVENTAIRE DES STOCKS", ln=True, fill=True)
        
        # En-tête
        pdf.set_font("Arial", 'B', 9)
        pdf.set_fill_color(240, 240, 240)
        pdf.cell(80, 8, "Produit", 1, 0, 'L', True)
        pdf.cell(30, 8, "Initial", 1, 0, 'C', True)
        pdf.cell(30, 8, "Vendu", 1, 0, 'C', True)
        pdf.cell(25, 8, "Reel", 1, 0, 'C', True)
        pdf.cell(25, 8, "Ecart", 1, 0, 'C', True)
        pdf.ln()
        
        pdf.set_font("Arial", '', 10)
        stocks = ShiftStock.query.filter_by(shift_id=sh_id).all()
        if not stocks:
            pdf.set_font("Arial", 'I', 10)
            pdf.cell(190, 10, "Aucun inventaire saisi pour ce service.", 1, 1, 'C')
        else:
            total_vendu = 0
            total_reel = 0
            for s in stocks:
                total_vendu += s.sales
                total_reel += s.rem
                diff = s.rem - (s.init - s.sales)
                pdf.cell(80, 8, clean_str(f"  {s.item.name}"), 1)
                pdf.cell(30, 8, str(s.init), 1, 0, 'C')
                pdf.cell(30, 8, str(s.sales), 1, 0, 'C')
                pdf.cell(25, 8, str(s.rem), 1, 0, 'C')
                if diff != 0: pdf.set_text_color(220, 53, 69)
                pdf.cell(25, 8, f"{'+' if diff>0 else ''}{diff}", 1, 0, 'C')
                pdf.set_text_color(0, 0, 0)
                pdf.ln()
            
            # Ligne de TOTAL
            pdf.set_font("Arial", 'B', 10)
            pdf.set_fill_color(240, 240, 240)
            pdf.cell(80, 9, " TOTAL", 1, 0, 'L', True)
            pdf.cell(30, 9, "", 1, 0, 'C', True)
            pdf.cell(30, 9, str(total_vendu), 1, 0, 'C', True)
            pdf.cell(25, 9, str(total_reel), 1, 0, 'C', True)
            pdf.cell(25, 9, "", 1, 0, 'C', True)
            pdf.ln()
        
        # ===== PIED DE PAGE =====
        pdf.ln(10)
        pdf.set_font("Arial", 'I', 8)
        pdf.cell(190, 5, f"Genere automatiquement par Supervision Pro - {sh.date_str}", 0, 1, 'C')

        # Timestamp pour éviter le cache
        ts = int(datetime.now().timestamp())
        report_name = f"rapport_{srv.name}_{sh.date_str}_{sh_id}_{ts}.pdf"
        pdf_path = os.path.join(basedir, 'static/reports', report_name)
        pdf.output(pdf_path)
        print(f"DEBUG PDF: Generated {report_name} with {len(stocks)} stock items.")
        return report_name
    except Exception as e:
        print(f"Error PDF: {e}")
        traceback.print_exc()
        return None

def send_weekly_email(cid, pdf_path=None, zip_path=None):
    import smtplib
    from email.mime.multipart import MIMEMultipart
    from email.mime.text import MIMEText
    from email.mime.base import MIMEBase
    from email import encoders

    config = EmailConfig.query.filter_by(company_id=cid).first()
    if not config: return False, "Configuration email manquante."
    
    try:
        msg = MIMEMultipart()
        msg['From'] = config.sender_email
        msg['To'] = config.recipient_email
        msg['Subject'] = f"RAPPORT HEBDOMADAIRE - {date.today().strftime('%d/%m/%Y')}"
        
        body = "Bonjour,\n\nVeuillez trouver ci-joint le rapport hebdomadaire consolidé (PDF) ainsi que l'archive de tous les rapports de service individuels (ZIP).\n\nCordialement,\nSupervision Pro"
        msg.attach(MIMEText(body, 'plain'))
        
        # Attachement PDF Consolidé
        if pdf_path and os.path.exists(pdf_path):
            with open(pdf_path, "rb") as f:
                part = MIMEBase("application", "octet-stream")
                part.set_payload(f.read())
            encoders.encode_base64(part)
            part.add_header("Content-Disposition", f"attachment; filename={os.path.basename(pdf_path)}")
            msg.attach(part)

        # Attachement ZIP des rapports individuels
        if zip_path and os.path.exists(zip_path):
            with open(zip_path, "rb") as f:
                part = MIMEBase("application", "zip")
                part.set_payload(f.read())
            encoders.encode_base64(part)
            part.add_header("Content-Disposition", f"attachment; filename={os.path.basename(zip_path)}")
            msg.attach(part)
        
        server = smtplib.SMTP(config.smtp_server, config.smtp_port)
        server.starttls()
        server.login(config.sender_email, config.password)
        server.send_message(msg)
        server.quit()
        return True, "Email envoyé avec succès."
    except Exception as e:
        return False, str(e)

# --- UTILS ---
def get_company_id():
    return session.get('company_id', 1) # Par défaut Melek

def is_manager():
    return session.get('role') == 'manager'

def is_server():
    return session.get('role') == 'server'

def is_hbg_any():
    uid = session.get('user_id'); cid = get_company_id()
    if not uid or session.get('role') != 'server': return False
    s = Server.query.filter_by(id=uid, company_id=cid).first()
    return s and s.department == 'hebergement'

def is_hbg_responsable():
    # Manager ou Serveur avec rôle 'responsable'
    cid = get_company_id(); uid = session.get('user_id')
    if session.get('role') == 'manager': return True
    if session.get('role') != 'server' or not uid: return False
    s = Server.query.filter_by(id=uid, company_id=cid).first()
    return s and s.department == 'hebergement' and s.hbg_role == 'responsable'

def is_hbg_agent():
    # Manager, ou Serveur avec rôle 'responsable' ou 'superviseur'
    cid = get_company_id(); uid = session.get('user_id')
    if session.get('role') == 'manager': return True
    if session.get('role') != 'server' or not uid: return False
    s = Server.query.filter_by(id=uid, company_id=cid).first()
    return s and s.department == 'hebergement' and s.hbg_role in ['superviseur', 'responsable']

def is_hbg_superviseur():
    # Uniquement le rôle superviseur (agent)
    cid = get_company_id(); uid = session.get('user_id')
    if session.get('role') != 'server' or not uid: return False
    s = Server.query.filter_by(id=uid, company_id=cid).first()
    return s and s.department == 'hebergement' and s.hbg_role == 'superviseur'

def clean_str(s):
    # FPDF1 latin-1 safe conversion
    if not isinstance(s, str): return str(s)
    return s.encode('latin-1', 'replace').decode('latin-1')

# --- ROUTES ---
@app.before_request
def check_license():
    exempt = ['activate', 'static', 'home', 'page_not_found', 'internal_error']
    if request.endpoint in exempt: return None
    if not session.get('active'):
        return redirect(url_for('activate'))

@app.route('/activate', methods=['GET', 'POST'])
def activate():
    if request.method == 'POST' and request.form.get('key') == "SUPER2026":
        session['active'] = True; return redirect(url_for('role_selection'))
    return render_template('activate.html')

@app.context_processor
def inject_unread_count():
    if not session.get('user_id') and not session.get('role') == 'manager':
        return dict(unread_count=0)
    try:
        cid = get_company_id()
        uid = session.get('user_id')
        role = session.get('role')
        if role == 'manager':
            count = Message.query.filter_by(company_id=cid, server_id=0, is_read=False).count()
        else:
            count = Message.query.filter(Message.company_id == cid, (Message.server_id == uid) | (Message.server_id == None), Message.is_read == False).count()
        return dict(unread_count=count)
    except:
        return dict(unread_count=0)

@app.route('/')
def home():
    return render_template('landing.html')

@app.route('/company/signup', methods=['GET', 'POST'])
def company_signup():
    if request.method == 'POST':
        name = request.form.get('name')
        email = request.form.get('email')
        code = request.form.get('code', '').upper().strip()
        manager_pass = request.form.get('password')
        
        if not name or not code or not manager_pass or not email:
            flash("Veuillez remplir tous les champs", "danger")
            return render_template('company_signup.html')
            
        if Company.query.filter((Company.name == name) | (Company.code == code)).first():
            flash("Ce nom ou code d'entreprise est déjà utilisé", "danger")
            return render_template('company_signup.html')
            
        new_co = Company(name=name, code=code)
        db.session.add(new_co)
        db.session.flush()
        
        # Création du manager par défaut avec email
        new_mgr = Manager(company_id=new_co.id, username=email, email=email, password_hash=generate_password_hash(manager_pass))
        db.session.add(new_mgr)
        db.session.commit()
        
        flash(f"Entreprise {name} créée avec succès ! Connectez-vous maintenant.", "success")
        return redirect(url_for('company_select'))
    return render_template('company_signup.html')

@app.route('/company/select', methods=['GET', 'POST'])
def company_select():
    if request.method == 'POST':
        code = request.form.get('code', '').upper().strip()
        co = Company.query.filter_by(code=code).first()
        if co:
            session['company_id'] = co.id
            session['company_name'] = co.name
            return redirect(url_for('role_selection'))
        flash("Code entreprise introuvable", "danger")
    return render_template('company_select.html')

@app.route('/login')
def role_selection():
    if not session.get('company_id'):
        return redirect(url_for('company_select'))
    if 'user_id' in session:
        return redirect(url_for('manager_dashboard' if session.get('role') == 'manager' else 'server_dashboard'))
    return render_template('choix_role.html')

@app.route('/login/server')
def login_server_select():
    cid = get_company_id()
    return render_template('login_server_select.html', servers=Server.query.filter_by(company_id=cid).all())

@app.route('/login/server/<int:server_id>', methods=['GET','POST'])
def login_server_auth(server_id):
    cid = get_company_id()
    s = Server.query.filter_by(id=server_id, company_id=cid).first_or_404()
    if not s.password_hash:
        return redirect(url_for('setup_password', role='server', user_id=server_id))
    if request.method == 'POST' and check_password_hash(s.password_hash, request.form.get('password')):
        session['role'] = 'server'; session['user_id'] = server_id; return redirect(url_for('server_dashboard'))
    return render_template('login_password.html', name=s.name)

@app.route('/login/manager', methods=['GET','POST'])
def login_manager():
    cid = get_company_id()
    if request.method == 'POST':
        identifier = request.form.get('username', 'admin')
        # Recherche par username OU email
        m = Manager.query.filter(
            (Manager.company_id == cid) & 
            ((Manager.username == identifier) | (Manager.email == identifier))
        ).first()
        
        if not m:
            flash("Identifiants incorrects", "danger")
            return render_template('login_password.html', name="Responsable", show_username=True)
            
        if not m.password_hash:
            return redirect(url_for('setup_password', role='manager', user_id=m.id))
        
        if check_password_hash(m.password_hash, request.form.get('password')):
            session['role'] = 'manager'; session['user_id'] = m.id; return redirect(url_for('manager_dashboard'))
        flash("Mot de passe incorrect", "danger")
        
    return render_template('login_password.html', name="Responsable", show_username=True)

@app.route('/setup-password/<role>/<int:user_id>', methods=['GET', 'POST'])
def setup_password(role, user_id):
    cid = get_company_id()
    if role == 'manager':
        user = Manager.query.filter_by(id=user_id, company_id=cid).first_or_404()
    else:
        user = Server.query.filter_by(id=user_id, company_id=cid).first_or_404()
        
    if request.method == 'POST':
        pw = generate_password_hash(request.form.get('password'))
        user.password_hash = pw
        db.session.commit(); return redirect(url_for('role_selection'))
    return render_template('definir_mot_de_passe.html')

# --- SERVER ACTIONS ---
@app.route('/dashboard/server')
def server_dashboard():
    try:
        uid = session.get('user_id'); tday = date.today(); cid = get_company_id()
        srv = Server.query.filter_by(id=uid, company_id=cid).first()
        ts = str(tday)
        if not srv: return redirect(url_for('logout'))
        
        # Hébergement → rediriger vers le tableau de bord dédié
        if srv.department == 'hebergement':
            return redirect(url_for('hbg_dashboard'))
        
        sh = Shift.query.filter_by(server_id=uid, date_str=ts).order_by(Shift.id.desc()).first()
        
        # ISO format consistency
        iso_year, iso_week, day_idx = tday.isocalendar()
        p = WeeklyPlan.query.filter_by(company_id=cid, server_id=uid, year=iso_year, week=iso_week, day_of_week=day_idx-1).first()
        
        expected_start_time_str = "08:00"
        theoretical_end_time_str = "16:00"
        is_planned_off = False

        if p:
            expected_start_time_str = p.start_time_str
            theoretical_end_time_str = p.end_time_str
            is_planned_off = p.is_off
        else:
            # Fallback : chercher n'importe quel planning du passé pour ce jour-là
            # Cela permet aux serveurs de voir un planning même si le manager n'a pas encore validé la semaine suivante
            old_p = WeeklyPlan.query.filter_by(company_id=cid, server_id=uid, day_of_week=day_idx-1).order_by(WeeklyPlan.year.desc(), WeeklyPlan.week.desc()).first()
            if old_p:
                expected_start_time_str = old_p.start_time_str
                theoretical_end_time_str = old_p.end_time_str
                is_planned_off = old_p.is_off
        
        t_by_p = {"Avant le service": [], "Pendant le service": [], "Après le service": []}
        # On récupère les tâches globales (assigned_server_id IS NULL) OU assignées spécifiquement à ce serveur
        all_tasks = Task.query.filter(
            Task.company_id == cid, 
            Task.department == srv.department,
            ((Task.assigned_server_id == None) | (Task.assigned_server_id == uid))
        ).all()
        for t in all_tasks:
            st = TaskStatus.query.filter_by(company_id=cid, server_id=uid, task_id=t.id, date_str=ts).first()
            if not st:
                st = TaskStatus(company_id=cid, server_id=uid, task_id=t.id, date_str=ts)
                db.session.add(st); db.session.commit()
            
            # Sécurité : si la phase n'est pas prévue, on l'ajoute dynamiquement ou on la met dans "Pendant le service"
            ph = t.phase if t.phase in t_by_p else "Pendant le service"
            t_by_p[ph].append({'task': t, 'status': st})
        
        msgs = Message.query.filter(
            Message.company_id == cid,
            ((Message.server_id == uid) | (Message.server_id == None) | (Message.sender_id == uid))
        ).order_by(Message.timestamp.asc()).all()
        
        my_plan_db = WeeklyPlan.query.filter_by(company_id=cid, server_id=uid, year=iso_year, week=iso_week).all()
        
        start_week = tday - timedelta(days=tday.weekday())
        week_shifts = Shift.query.filter(Shift.server_id == uid, Shift.date_str >= str(start_week)).all()
        srv_shift_dates = [ws.date_str for ws in week_shifts]
        
        # ALERTES : Tâches en retard non faites
        overdue_tasks = []
        current_time_str = datetime.now().strftime('%H:%M')
        for phase, items in t_by_p.items():
            for item in items:
                t = item['task']
                st = item['status']
                if not st.is_done and t.scheduled_time and t.scheduled_time < current_time_str:
                    overdue_tasks.append(t)

        return render_template('serveur_dashboard.html', 
                             server=srv, shift=sh, today_date=tday.strftime('%d/%m/%Y'), 
                             messages=msgs, my_plan=my_plan_db,
                             current_week=iso_week,
                             shift_dates=srv_shift_dates,
                             expected_start=expected_start_time_str, 
                             theoretical_end=theoretical_end_time_str, 
                             is_planned_off=is_planned_off,
                             stock_items=StockItem.query.filter_by(company_id=cid, department=srv.department).all(),
                             total_tasks=total_tasks,
                             overdue_tasks=overdue_tasks)
    except Exception as e:
        print(f"Server Dashboard Error: {e}")
        traceback.print_exc()
        flash("Une erreur est survenue. Veuillez réessayer.", "danger")
        return redirect(url_for('role_selection'))

@app.route('/start_shift', methods=['POST'])
def start_shift():
    uid = session.get('user_id')
    if not uid: return redirect(url_for('role_selection'))
    
    now = datetime.now(); tday = date.today(); tday_str = str(tday)
    cid = get_company_id()
    iso_year, iso_week, day_idx = tday.isocalendar()
    
    plan = WeeklyPlan.query.filter_by(company_id=cid, server_id=uid, year=iso_year, week=iso_week, day_of_week=day_idx-1).first()
    
    lateness = 0
    if plan and not plan.is_off:
        try:
            exp_h, exp_m = map(int, plan.start_time_str.split(':'))
            expected = now.replace(hour=exp_h, minute=exp_m, second=0, microsecond=0)
            if now > expected:
                lateness = int((now - expected).total_seconds() / 60)
        except: pass
        
    s = Server.query.filter_by(id=uid, company_id=cid).first()
    if not s: return redirect(url_for('logout'))
    
    db.session.add(Shift(company_id=cid, server_id=uid, date_str=tday_str, actual_start_time=now, lateness_minutes=lateness))
    db.session.commit()
    return redirect(url_for('server_dashboard'))

# --- Sauvegarde du stock par le serveur (pendant le shift) ---
@app.route('/api/save_stock', methods=['POST'])
def save_stock():
    data = request.get_json()
    uid = session.get('user_id')
    sh = Shift.query.filter_by(server_id=uid, actual_end_time=None).first()
    if not sh:
        return jsonify(success=False, error='Aucun shift actif')
    for item_data in data.get('stock', []):
        item_id = int(item_data['item_id'])
        init_qty = int(item_data['init'])
        sold_qty = int(item_data['sold'])
        # Mettre à jour le stock global (filtré par item_id et shift existant)
        item = StockItem.query.filter_by(id=item_id, company_id=sh.company_id).first()
        if item:
            item.current_quantity = init_qty - sold_qty
    db.session.commit()
    return jsonify(success=True)

@app.route('/end_shift', methods=['POST'])
def end_shift():
    uid = session.get('user_id')
    if not uid: return jsonify(success=False, error="Sesssion expirée")
    
    now = datetime.now()
    sh = Shift.query.filter_by(server_id=uid, actual_end_time=None).first()
    if sh:
        try:
            # Calcul heures sup
            ovt = 0
            tday = date.today()
            iso_year, iso_week, day_idx = tday.isocalendar()
            plan = WeeklyPlan.query.filter_by(server_id=sh.server_id, year=iso_year, week=iso_week, day_of_week=day_idx-1).first()
            if plan and not plan.is_off:
                try:
                    exp_h, exp_m = map(int, plan.end_time_str.split(':'))
                    expected_end = now.replace(hour=exp_h, minute=exp_m, second=0, microsecond=0)
                    if now > expected_end:
                        ovt = int((now - expected_end).total_seconds() / 60)
                except: pass

            sh.actual_end_time = now; sh.overtime_minutes = ovt
            data = request.get_json()
            if data and 'stock' in data:
                for it in data['stock']:
                    sid = int(it['id'])
                    item = StockItem.query.filter_by(id=sid, company_id=sh.company_id).first()
                    if item:
                        iv = item.current_quantity # Stock initial = stock actuel en base
                        sv = int(it.get('sales') or 0)
                        rv = int(it.get('real') or 0) # Stock réel compté
                        
                        # Mise à jour du stock principal
                        item.current_quantity = rv
                        
                        # Enregistrement du détail du shift
                        db.session.add(ShiftStock(
                            company_id=sh.company_id,
                            shift_id=sh.id, 
                            item_id=item.id, 
                            init=iv, 
                            sales=sv, 
                            rem=rv
                        ))
                        
                        # Si écart significatif, on peut notifier (optionnel)
                        theo = iv - sv
                        if theo != rv:
                            print(f"[STOCK] Ecart pour {item.name}: Theo {theo} vs Réel {rv}")
            # Analyse des tâches oubliées pour notification
            undone_tasks = TaskStatus.query.filter_by(server_id=uid, date_str=sh.date_str, is_done=False).all()
            if undone_tasks:
                srv = Server.query.get(uid)
                names = []
                for st in undone_tasks:
                    t = Task.query.get(st.task_id)
                    if t: names.append(t.name)
                
                if names:
                    db.session.add(Message(
                        company_id=sh.company_id,
                        server_id=0, # Manager
                        sender_id=uid,
                        content=f"⚠️ TACHES NON FAITES ({srv.name}) : {', '.join(names[:3])}" + ("..." if len(names)>3 else "")
                    ))

            db.session.commit()
            
            # Essayer de générer le PDF, mais ne pas bloquer si échec
            try:
                generate_pdf(sh.id)
            except Exception as pdf_e:
                print(f"PDF Gen Error: {pdf_e}")
                
            return jsonify(success=True)
        except Exception as e:
            db.session.rollback()
            return jsonify(success=False, error=str(e))
    return jsonify(success=False, error="Aucun shift actif trouvé")

# --- VENTE EN TEMPS RÉEL (Serveur) ---
@app.route('/api/record_sale', methods=['POST'])
def record_sale():
    data = request.get_json()
    uid = session.get('user_id')
    sh = Shift.query.filter_by(server_id=uid, actual_end_time=None).first()
    if not sh:
        return jsonify(success=False, error='Aucun shift actif')
    item_id = int(data.get('item_id'))
    qty = int(data.get('quantity', 1))
    item = StockItem.query.filter_by(id=item_id, company_id=sh.company_id).first()
    if not item:
        return jsonify(success=False, error='Produit introuvable')
    # Enregistrer la vente
    db.session.add(SaleRecord(shift_id=sh.id, item_id=item_id, quantity=qty))
    item.current_quantity -= qty
    db.session.add(StockTransaction(company_id=sh.company_id, item_id=item_id, quantity=-qty, type='OUT', shift_id=sh.id))
    db.session.commit()
    return jsonify(success=True, new_qty=item.current_quantity)

@app.route('/api/shift_sales')
def get_shift_sales():
    uid = session.get('user_id')
    sh = Shift.query.filter_by(server_id=uid, actual_end_time=None).first()
    if not sh:
        return jsonify(sales=[])
    sales = SaleRecord.query.filter_by(shift_id=sh.id).order_by(SaleRecord.timestamp.desc()).all()
    return jsonify(sales=[{
        'id': s.id, 
        'item_name': s.item.name, 
        'quantity': s.quantity, 
        'time': s.timestamp.strftime('%H:%M')
    } for s in sales])

@app.route('/dashboard/manager')
def manager_dashboard():
    if not (is_manager() or is_hbg_any()): return redirect(url_for('login'))
    cid = get_company_id()
    co = Company.query.get(cid)
    if co and co.last_report_sent:
        session['company_last_report'] = co.last_report_sent.strftime('%d/%m/%Y')
    else:
        session['company_last_report'] = None
    
    # Détection automatique de la section pour les employés Hébergement
    if is_hbg_any() and not is_manager():
        section = 'hebergement'
    else:
        section = request.args.get('section', 'restauration')
    
    # 1. Récupération des employés de la section
    servers = Server.query.filter_by(company_id=cid, department=section).all()
    server_ids = [s.id for s in servers]
    
    # 2. Shifts actifs (filtrés par employés de la section)
    if server_ids:
        active_shifts = Shift.query.filter(Shift.company_id == cid, Shift.server_id.in_(server_ids), Shift.actual_end_time == None).all()
    else:
        active_shifts = []
    
    # 3. Events de la section
    events = Event.query.filter(Event.company_id == cid, (Event.department == section) | (Event.department == None)).all()
    
    # 4. Calcul de l'état de présence
    server_statuses = []
    now = datetime.now()
    tday = date.today()
    iso_year, iso_week, day_idx = tday.isocalendar()
    
    for srv in servers:
        plan = WeeklyPlan.query.filter_by(company_id=cid, server_id=srv.id, year=iso_year, week=iso_week, day_of_week=day_idx-1).first()
        
        status = "waiting"
        details = "Pas d'horaire"
        planning_info = "-"
        
        current_shift = next((sh for sh in active_shifts if sh.server_id == srv.id), None)
        # Vérifier aussi les shifts terminés aujourd'hui
        today_shift = Shift.query.filter_by(company_id=cid, server_id=srv.id, date_str=str(tday)).first()
        
        if current_shift:
            status = "present"
            startTime = current_shift.actual_start_time.strftime('%H:%M')
            late_info = ""
            if current_shift.lateness_minutes and current_shift.lateness_minutes > 0:
                late_info = f" (Retard: {current_shift.lateness_minutes}min)"
            details = f"En service depuis {startTime}{late_info}"
            planning_info = "En poste"
        elif today_shift and today_shift.actual_end_time:
            status = "present"
            details = f"Service terminé à {today_shift.actual_end_time.strftime('%H:%M')}"
            planning_info = "Terminé"
        elif plan:
            if plan.is_off:
                status = "off"
                details = "Repos (OFF)"
                planning_info = "OFF"
            else:
                planning_info = f"{plan.start_time_str} - {plan.end_time_str}"
                try:
                    h, m_val = map(int, plan.start_time_str.split(':'))
                    planned_start = datetime.combine(tday, time(h, m_val))
                    minutes_late = (now - planned_start).total_seconds() / 60
                    
                    if minutes_late > 60:
                        # Plus d'1h de retard sans pointer = ABSENT
                        status = "absent"
                        details = f"ABSENT — Attendu à {plan.start_time_str}"
                    elif minutes_late > 0:
                        # En retard mais pas encore absent
                        status = "missing"
                        details = f"Retard ({int(minutes_late)}min) — Attendu à {plan.start_time_str}"
                    else:
                        status = "waiting"
                        details = f"Prévu à {plan.start_time_str}"
                except: pass
        
        # Tâches en retard
        overdue_count = 0
        current_time_str = now.strftime('%H:%M')
        # On ne compte les retards que pour la section actuelle
        sect_tasks = Task.query.filter_by(company_id=cid, department=section).all()
        for t in sect_tasks:
            st = TaskStatus.query.filter_by(company_id=cid, server_id=srv.id, task_id=t.id, date_str=str(tday)).first()
            is_done = st.is_done if st else False
            if not is_done and t.scheduled_time and t.scheduled_time < current_time_str:
                overdue_count += 1

        server_statuses.append({
            'name': srv.name,
            'status': status,
            'details': details,
            'planning': planning_info,
            'id': srv.id,
            'overdue_count': overdue_count
        })

    # 5. Messages de la société
    msgs = Message.query.filter_by(company_id=cid).order_by(Message.timestamp.desc()).limit(20).all()
    msgs.reverse()

    # 6. Données détaillées pour le monitoring temps réel & Modals
    daily_done = db.session.query(db.func.count(TaskStatus.id)).filter(
        TaskStatus.company_id == cid,
        TaskStatus.date_str == str(tday),
        TaskStatus.is_done == True,
        TaskStatus.task_id.in_(db.session.query(Task.id).filter(Task.department == section))
    ).scalar() or 0
    daily_total = db.session.query(db.func.count(TaskStatus.id)).filter(
        TaskStatus.company_id == cid,
        TaskStatus.date_str == str(tday),
        TaskStatus.task_id.in_(db.session.query(Task.id).filter(Task.department == section))
    ).scalar() or 0
    daily_percent = int((daily_done / daily_total * 100)) if daily_total > 0 else 0
    
    stock_items = StockItem.query.filter_by(company_id=cid, department=section).all()
    low_stock_count = sum(1 for i in stock_items if i.current_quantity <= i.min_threshold)
    
    live_stocks = []
    for item in stock_items:
        today_sales = db.session.query(db.func.sum(ShiftStock.sales)).filter(
            ShiftStock.item_id == item.id,
            ShiftStock.shift_id.in_(db.session.query(Shift.id).filter(Shift.date_str == str(tday)))
        ).scalar() or 0
        live_stocks.append({
            'name': item.name,
            'current': item.current_quantity,
            'threshold': item.min_threshold,
            'today_sales': today_sales,
            'initial': item.current_quantity + today_sales
        })

    # Reconstruction de dashboard_data pour la compatibilité template
    dashboard_data = []
    for srv in servers:
        curr_sh = next((sh for sh in active_shifts if sh.server_id == srv.id), None)
        task_details = []
        if curr_sh:
            sect_tasks = Task.query.filter_by(company_id=cid, department=section).all()
            for t in sect_tasks:
                if t.assigned_server_id is not None and t.assigned_server_id != srv.id:
                    continue
                st = TaskStatus.query.filter_by(server_id=srv.id, task_id=t.id, date_str=str(tday)).first()
                task_details.append((t, st))
        
        dashboard_data.append({
            'server': srv,
            'shift': curr_sh,
            'tasks': {'details': task_details}
        })

    # Mapper les noms des serveurs pour le chat
    server_names = {s.id: s.name for s in Server.query.filter_by(company_id=cid).all()}

    # Calcul des alertes de retard
    overdue_alerts = []
    current_ts = now.strftime('%H:%M')
    for srv_obj in servers:
        srv_task_pool = Task.query.filter_by(company_id=cid, department=section).all()
        for t_obj in srv_task_pool:
            if t_obj.scheduled_time and t_obj.scheduled_time < current_ts:
                if t_obj.assigned_server_id is None or t_obj.assigned_server_id == srv_obj.id:
                    st_obj = TaskStatus.query.filter_by(server_id=srv_obj.id, task_id=t_obj.id, date_str=str(tday)).first()
                    if not st_obj or not st_obj.is_done:
                        overdue_alerts.append({'srv': srv_obj.name.capitalize(), 'task': t_obj.name, 'time': t_obj.scheduled_time})
        
        # Alerte Stock non saisi pour les shifts actifs
        sh_active = Shift.query.filter_by(server_id=srv_obj.id, actual_end_time=None, date_str=str(tday)).first()
        if sh_active and current_ts > "15:00":
            stock_count = ShiftStock.query.filter_by(shift_id=sh_active.id).count()
            if stock_count == 0:
                overdue_alerts.append({'srv': srv_obj.name.capitalize(), 'task': "Inventaire de Stock non commencé", 'time': "Aujourd'hui"})

    return render_template('responsable_dashboard.html', 
                         servers=server_statuses, active_shifts=active_shifts, 
                         events=events, messages=msgs, data=dashboard_data,
                         server_names=server_names,
                         current_section=section,
                         daily_stats={'done': daily_done, 'total': daily_total, 'percent': daily_percent},
                         low_stock_count=low_stock_count,
                         live_stocks=live_stocks,
                         overdue_alerts=overdue_alerts)

# --- ROUTES HÉBERGEMENT (DYNAMIQUE) ---
@app.route('/hebergement/dashboard')
def hbg_dashboard():
    if not (is_manager() or is_hbg_any()): return redirect(url_for('login'))
    cid = get_company_id()
    tables = HbgTable.query.filter_by(company_id=cid).order_by(HbgTable.created_at.desc()).all()
    return render_template('hbg_dashboard.html', tables=tables, can_manage=is_hbg_responsable())

@app.route('/hebergement/table/add', methods=['POST'])
def hbg_add_table():
    if not is_hbg_responsable(): return redirect(url_for('login'))
    cid = get_company_id()
    name = request.form.get('name')
    t_type = request.form.get('type', 'inspection')
    if name:
        new_table = HbgTable(company_id=cid, name=name, table_type=t_type)
        db.session.add(new_table)
        db.session.commit()
        flash(f"Tableau '{name}' créé.", "success")
    return redirect(url_for('hbg_dashboard'))

@app.route('/hebergement/table/<int:table_id>')
def hbg_view_table(table_id):
    if not (is_manager() or is_hbg_any()): return redirect(url_for('login'))
    cid = get_company_id()
    table = HbgTable.query.filter_by(id=table_id, company_id=cid).first_or_404()
    columns = HbgColumn.query.filter_by(table_id=table.id).order_by(HbgColumn.order).all()
    rows = HbgRow.query.filter_by(table_id=table.id).order_by(HbgRow.order).all()
    
    # Charger les cellules
    cells = {}
    for r in rows:
        for c in columns:
            cell = HbgCell.query.filter_by(row_id=r.id, col_id=c.id).first()
            cells[(r.id, c.id)] = cell.value if cell else ""
            
    return render_template('hbg_dynamic_table.html', 
                         table=table, columns=columns, rows=rows, cells=cells,
                         can_manage=is_hbg_responsable(), is_agent=is_hbg_superviseur())

@app.route('/hebergement/table/<int:table_id>/add_col', methods=['POST'])
def hbg_add_column(table_id):
    if not is_hbg_responsable(): return redirect(url_for('login'))
    label = request.form.get('label')
    if label:
        count = HbgColumn.query.filter_by(table_id=table_id).count()
        db.session.add(HbgColumn(table_id=table_id, label=label, order=count))
        db.session.commit()
    return redirect(url_for('hbg_view_table', table_id=table_id))

@app.route('/hebergement/table/<int:table_id>/add_row', methods=['POST'])
def hbg_add_row(table_id):
    if not is_hbg_responsable(): return redirect(url_for('login'))
    label = request.form.get('label')
    if label:
        count = HbgRow.query.filter_by(table_id=table_id).count()
        db.session.add(HbgRow(table_id=table_id, label=label, order=count))
        db.session.commit()
    return redirect(url_for('hbg_view_table', table_id=table_id))

@app.route('/hebergement/table/<int:table_id>/delete', methods=['POST'])
def hbg_delete_table(table_id):
    if not is_hbg_responsable(): return redirect(url_for('login'))
    cid = get_company_id()
    table = HbgTable.query.filter_by(id=table_id, company_id=cid).first_or_404()
    # Suppression en cascade manuelle (ou via relationship si configuré)
    rows = HbgRow.query.filter_by(table_id=table.id).all()
    cols = HbgColumn.query.filter_by(table_id=table.id).all()
    for r in rows:
        HbgCell.query.filter_by(row_id=r.id).delete()
        db.session.delete(r)
    for c in cols:
        db.session.delete(c)
    db.session.delete(table)
    db.session.commit()
    flash("Tableau supprimé.", "secondary")
    return redirect(url_for('hbg_dashboard'))

@app.route('/hebergement/cell/update', methods=['POST'])
def hbg_update_cell():
    if not (is_manager() or is_hbg_agent()): return jsonify(success=False), 403
    rid = request.form.get('row_id')
    clid = request.form.get('col_id')
    val = request.form.get('value')
    cid = get_company_id()
    
    # Sécurisation multi-sociétés : Vérifier que la ligne appartient à la société
    row = HbgRow.query.filter_by(id=rid).first()
    if not row: return jsonify(success=False, error="Ligne introuvable"), 404
    
    table = HbgTable.query.filter_by(id=row.table_id, company_id=cid).first()
    if not table: return jsonify(success=False, error="Accès interdit"), 403
    
    # Vérifier aussi la colonne par précaution
    col = HbgColumn.query.filter_by(id=clid, table_id=table.id).first()
    if not col: return jsonify(success=False, error="Colonne invalide"), 400
    
    cell = HbgCell.query.filter_by(row_id=rid, col_id=clid).first()
    if not cell:
        cell = HbgCell(row_id=rid, col_id=clid)
        db.session.add(cell)
    cell.value = val
    db.session.commit()
    return jsonify(success=True)

@app.route('/hebergement/inspection')
def hbg_inspection():
    # Redirection vers le nouveau dashboard
    return redirect(url_for('hbg_dashboard'))

@app.route('/hebergement/followup')
def hbg_followup():
    # Redirection vers le nouveau dashboard
    return redirect(url_for('hbg_dashboard'))

@app.route('/hebergement/ai')
def hbg_ai():
    if not (is_manager() or is_hbg_any()): return redirect(url_for('login'))
    return render_template('hbg_ai_assistant.html')

@app.route('/dashboard/manager/planning', methods=['GET', 'POST'])
def planning_view():
    if not is_manager(): return redirect(url_for('login'))
    cid = get_company_id()
    # On laisse le choix de la section (restauration/hebergement)
    section = request.args.get('section', 'restauration')
    
    tday = date.today()
    iso_year, iso_week, _ = tday.isocalendar()
    y = int(request.args.get('year', iso_year))
    w = int(request.args.get('week', iso_week))
    
    servers = Server.query.filter_by(company_id=cid, department=section).all()
    
    if request.method == 'POST':
        for srv in servers:
            for day in range(7):
                start = request.form.get(f'start_{srv.id}_{day}')
                end = request.form.get(f'end_{srv.id}_{day}')
                off = request.form.get(f'off_{srv.id}_{day}') == 'on'
                
                plan = WeeklyPlan.query.filter_by(company_id=cid, server_id=srv.id, year=y, week=w, day_of_week=day).first()
                if not plan:
                    plan = WeeklyPlan(company_id=cid, server_id=srv.id, year=y, week=w, day_of_week=day)
                    db.session.add(plan)
                
                # Mise à jour forcée pour assurer la cohérence (même sur les vieux plans)
                plan.company_id = cid
                plan.year = y
                plan.week = w
                plan.start_time_str = start
                plan.end_time_str = end
                plan.is_off = off
        db.session.commit()
        flash("Planning enregistré.", "success")
        return redirect(url_for('planning_view', section=section, year=y, week=w))
    
    plans = WeeklyPlan.query.filter_by(company_id=cid, year=y, week=w).all()
    planning_dict = {(p.server_id, p.day_of_week): p for p in plans}
    
    # Map des shifts pour cocher "Présent" dans le planning
    # On cherche les shifts dont la date correspond aux jours de la semaine y/w
    try:
        # date.fromisocalendar est dispo depuis Python 3.8+
        start_monday = date.fromisocalendar(y, w, 1)
        end_sunday = start_monday + timedelta(days=6)
    except:
        # Fallback pour versions plus anciennes si besoin (peu probable en 2026)
        start_monday = tday - timedelta(days=tday.weekday())
        end_sunday = start_monday + timedelta(days=6)

    shifts = Shift.query.filter(Shift.company_id == cid, Shift.date_str >= str(start_monday), Shift.date_str <= str(end_sunday)).all()
    
    shift_map = {}
    for sh in shifts:
        try:
            d_obj = datetime.strptime(sh.date_str, '%Y-%m-%d').date()
            day_idx = d_obj.weekday() # 0-6
            shift_map[(sh.server_id, day_idx)] = True
        except: continue

    return render_template('responsable_planning.html',
                         servers=servers,
                         planning=planning_dict,
                         shift_map=shift_map,
                         year=y, week=w,
                         today=tday,
                         selected_year=y, selected_week=w,
                         current_section=section)


@app.route('/dashboard/manager/planning/pdf')
def download_planning_pdf():
    if not is_manager(): return redirect(url_for('login'))
    cid = get_company_id()
    if not FPDF: return jsonify({"success": False, "error": "Librarie PDF manquante."})
    try:
        section = request.args.get('section', 'restauration')
        tday = date.today()
        iso_year, iso_week, _ = tday.isocalendar()
        y = int(request.args.get('year', iso_year))
        w = int(request.args.get('week', iso_week))
        
        pdf = FPDF(orientation='L', unit='mm', format='A4')
        pdf.add_page()
        pdf.set_fill_color(15, 23, 42); pdf.set_text_color(255, 255, 255)
        pdf.set_font("Arial", 'B', 16)
        
        monday = date.fromisocalendar(y, w, 1)
        sunday = monday + timedelta(days=6)
        
        pdf.cell(280, 15, clean_str(f"PLANNING SEMAINE {w} ({monday.strftime('%d/%m')} - {sunday.strftime('%d/%m')})"), ln=True, align='C', fill=True)
        pdf.ln(5)
        
        # En-tête
        days_fr = ["LUN", "MAR", "MER", "JEU", "VEN", "SAM", "DIM"]
        col_srv = 50
        col_day = 32
        
        pdf.set_font("Arial", 'B', 9)
        pdf.set_fill_color(51, 65, 85)
        pdf.cell(col_srv, 10, "COLLABORATEUR", 1, 0, 'C', True)
        for d in days_fr:
            pdf.cell(col_day, 10, d, 1, 0, 'C', True)
        pdf.ln()
        
        pdf.set_text_color(0, 0, 0); pdf.set_font("Arial", '', 8)
        servers = Server.query.filter_by(company_id=cid, department=section).all()
        for srv in servers:
            pdf.set_fill_color(241, 245, 249)
            pdf.cell(col_srv, 12, clean_str(srv.name.upper()), 1, 0, 'L', True)
            for d_idx in range(7):
                p = WeeklyPlan.query.filter_by(company_id=cid, server_id=srv.id, year=y, week=w, day_of_week=d_idx).first()
                txt = "-"
                bg = False
                if p:
                    if p.is_off:
                        txt = "OFF"
                        pdf.set_fill_color(254, 226, 226)
                        bg = True
                    else:
                        txt = f"{p.start_time_str}-{p.end_time_str}"
                pdf.cell(col_day, 12, txt, 1, 0, 'C', bg)
            pdf.ln()
            
        pdf_name = f"planning_W{w}_{y}.pdf"
        path = os.path.join(basedir, 'static/reports', pdf_name)
        pdf.output(path)
        return redirect(url_for('static', filename=f'reports/{pdf_name}'))
    except Exception as e:
        traceback.print_exc()
        return f"Erreur PDF: {e}", 500

@app.route('/dashboard/server/planning/pdf')
def download_server_planning_pdf():
    uid = session.get('user_id'); cid = get_company_id()
    srv = Server.query.get(uid)
    if not srv or not FPDF: return redirect(url_for('server_dashboard'))
    
    tday = date.today()
    iso_year, iso_week, _ = tday.isocalendar()
    plans = WeeklyPlan.query.filter_by(company_id=cid, server_id=uid, year=iso_year, week=iso_week).all()
    
    pdf = FPDF()
    pdf.add_page()
    pdf.set_font("Arial", 'B', 16)
    pdf.cell(190, 15, clean_str(f"MON PLANNING - {srv.name.upper()}"), ln=True, align='C')
    pdf.set_font("Arial", 'B', 12)
    pdf.cell(190, 10, clean_str(f"Semaine {iso_week} ({iso_year})"), ln=True, align='C')
    pdf.ln(10)
    
    pdf.set_fill_color(30, 41, 59); pdf.set_text_color(255, 255, 255)
    pdf.cell(95, 10, "JOUR", 1, 0, 'C', True)
    pdf.cell(95, 10, "HORAIRES / STATUT", 1, 1, 'C', True)
    
    pdf.set_text_color(0, 0, 0); pdf.set_font("Arial", '', 11)
    days = ["Lundi", "Mardi", "Mercredi", "Jeudi", "Vendredi", "Samedi", "Dimanche"]
    for i, d_name in enumerate(days):
        p = next((p for p in plans if p.day_of_week == i), None)
        txt = "NON PROGRAMMÉ"
        if p: txt = "REPOS (OFF)" if p.is_off else f"{p.start_time_str} - {p.end_time_str}"
        pdf.cell(95, 12, clean_str(d_name), 1, 0, 'C')
        pdf.cell(95, 12, clean_str(txt), 1, 1, 'C')
        
    pdf_name = f"planning_srv_{uid}_W{iso_week}.pdf"
    path = os.path.join(basedir, 'static/reports', pdf_name)
    pdf.output(path)
    return redirect(url_for('static', filename=f'reports/{pdf_name}'))

@app.route('/dashboard/manager/email-config', methods=['GET', 'POST'])
def email_config():
    if not is_manager(): return redirect(url_for('login'))
    cid = get_company_id()
    conf = EmailConfig.query.filter_by(company_id=cid).first()
    if not conf:
        conf = EmailConfig(company_id=cid)
        db.session.add(conf)
        db.session.commit() # Create if missing

    if request.method == 'POST':
        conf.smtp_server = request.form.get('smtp_server')
        conf.smtp_port = int(request.form.get('smtp_port') or 587)
        conf.sender_email = request.form.get('sender_email')
        conf.password = request.form.get('password')
        conf.recipient_email = request.form.get('recipient_email')
        db.session.commit()
        flash("Configuration email enregistree.", "success")
        return redirect(url_for('manager_dashboard'))
    return render_template('email_config.html', config=conf)

@app.route('/dashboard/manager/send-weekly')
def trigger_weekly_report():
    if not is_manager(): return redirect(url_for('login'))
    cid = get_company_id()
    success, msg = send_weekly_email(cid)
    flash(msg, "success" if success else "danger")
    return redirect(url_for('manager_dashboard'))
@app.route('/dashboard/manager/tasks', methods=['GET', 'POST'])
def manage_tasks():
    if not is_manager(): return redirect(url_for('login'))
    cid = get_company_id()
    section = request.args.get('section', 'restauration')
    
    if request.method == 'POST':
        action = request.form.get('action')
        if action == 'add':
            new_t = Task(
                company_id=cid,
                phase=request.form.get('phase'),
                name=request.form.get('name'),
                scheduled_time=request.form.get('scheduled_time'),
                required_people=int(request.form.get('required_people') or 1),
                department=section,
                assigned_server_id=int(request.form.get('assigned_server_id')) if request.form.get('assigned_server_id') else None
            )
            db.session.add(new_t)
            flash("Checklist ajoutée.", "success")
        elif action == 'edit':
            t = Task.query.filter_by(id=request.form.get('id'), company_id=cid).first()
            if t:
                t.phase = request.form.get('phase')
                t.name = request.form.get('name')
                t.scheduled_time = request.form.get('scheduled_time')
                t.required_people = int(request.form.get('required_people') or 1)
                t.assigned_server_id = int(request.form.get('assigned_server_id')) if request.form.get('assigned_server_id') else None
        elif action == 'delete':
            t = Task.query.filter_by(id=request.form.get('id'), company_id=cid).first()
            if t: db.session.delete(t)
        db.session.commit()
        return redirect(url_for('manage_tasks', section=section))
    
    tasks = Task.query.filter_by(company_id=cid, department=section).order_by(Task.phase, Task.scheduled_time).all()
    servers = Server.query.filter_by(company_id=cid, department=section).all()
    return render_template('manage_tasks.html', tasks=tasks, servers=servers, current_section=section)

@app.route('/dashboard/manager/servers', methods=['GET', 'POST'])
def manage_servers():
    if not is_manager(): return redirect(url_for('login'))
    cid = get_company_id()
    section = request.args.get('section', 'restauration')
    
    if request.method == 'POST':
        action = request.form.get('action')
        name = request.form.get('name')
        
        if action == 'add' and name:
            name = name.strip().lower()
            if not Server.query.filter_by(company_id=cid, name=name).first():
                db.session.add(Server(company_id=cid, name=name, department=section))
                db.session.commit()
                flash(f"Collaborateur {name} ajouté ({section}).", "success")
            else:
                flash("Nom existant dans votre entreprise.", "warning")
        elif action == 'rename':
            s = Server.query.filter_by(id=request.form.get('id'), company_id=cid).first()
            if s and name: 
                s.name = name.strip().lower()
                db.session.commit()
        elif action == 'delete':
            s = Server.query.filter_by(id=request.form.get('id'), company_id=cid).first()
            if s: 
                db.session.delete(s)
                db.session.commit()
        return redirect(url_for('manage_servers', section=section))
        
    servers = Server.query.filter_by(company_id=cid, department=section).all()
    return render_template('manage_servers.html', servers=servers, current_section=section)

@app.route('/rename_server', methods=['POST'])
def rename_server():
    # Compatibilité pour le planning
    s = Server.query.get(request.form.get('server_id'))
    if s:
        s.name = request.form.get('new_name').strip().lower()
        db.session.commit()
        flash("Collaborateur renommé.", "success")
    return redirect(url_for('planning_view'))

@app.route('/dashboard/manager/stock', methods=['GET','POST'])
def stock_manager():
    if not is_manager(): return redirect(url_for('login'))
    cid = get_company_id()
    section = request.args.get('section', 'restauration')
    
    if request.method == 'POST':
        action = request.form.get('action')
        if action == 'add_item':
            name = request.form.get('name')
            init_qty = int(request.form.get('quantity') or 0)
            threshold = int(request.form.get('threshold') or 5)
            if name:
                new_item = StockItem(company_id=cid, name=name, current_quantity=init_qty, min_threshold=threshold, department=section)
                db.session.add(new_item)
                db.session.commit()
                if init_qty > 0:
                    db.session.add(StockTransaction(company_id=cid, item_id=new_item.id, quantity=init_qty, type='IN'))
        elif action == 'update_qty':
            item_id = int(request.form.get('id'))
            add_qty = int(request.form.get('add_quantity') or 0)
            item = StockItem.query.filter_by(id=item_id, company_id=cid).first()
            if item:
                item.current_quantity += add_qty
                db.session.add(StockTransaction(company_id=cid, item_id=item.id, quantity=add_qty, type='IN'))
                
                # Notification Manager si réapprovisionnement positif
                if add_qty > 0:
                    db.session.add(Message(
                        company_id=cid,
                        server_id=0, # Manager
                        sender_id=session.get('user_id', 0),
                        content=f"📦 REAPPROVISIONNEMENT : {item.name} (+{add_qty}). Nouveau stock : {item.current_quantity}"
                    ))
        elif action == 'delete_item':
            item = StockItem.query.filter_by(id=request.form.get('id'), company_id=cid).first()
            if item: db.session.delete(item)
        db.session.commit()
        return redirect(url_for('stock_manager', section=section))
    
    tday_str = str(date.today())
    stock_summary = []
    
    items = StockItem.query.filter_by(company_id=cid, department=section).all()
    
    for item in items:
        # Données de shift pour aujourd'hui
        shifts_data = ShiftStock.query.join(Shift, ShiftStock.shift_id == Shift.id).filter(
            Shift.company_id == cid,
            ShiftStock.item_id == item.id,
            Shift.date_str == tday_str
        ).all()
        
        total_sales = sum(s.sales for s in shifts_data)
        
        first_shift = ShiftStock.query.join(Shift, ShiftStock.shift_id == Shift.id).filter(
            Shift.company_id == cid,
            ShiftStock.item_id == item.id,
            Shift.date_str == tday_str
        ).order_by(Shift.actual_start_time).first()
        
        initial = first_shift.init if first_shift else item.current_quantity + total_sales
        
        stock_summary.append({
            'item': item,
            'initial': initial,
            'sales': total_sales,
            'remaining': item.current_quantity
        })
    
    return render_template('stock_manager.html', items=stock_summary, current_section=section)

@app.route('/send_chat', methods=['POST'])
def send_chat():
    content = request.form.get('content')
    recipient_id = request.form.get('recipient_id') # 'all', 'manager', or server_id
    sender_id = session.get('user_id') if session.get('role') == 'server' else 0 # 0 for manager
    
    image = request.files.get('image')
    audio = request.files.get('audio')
    img_path = None
    aud_path = None

    if image:
        fname = f"img_{datetime.now().strftime('%m%d_%H%M%S')}_{image.filename}"
        image.save(os.path.join(basedir, 'static/uploads', fname))
        img_path = f"uploads/{fname}"
    
    if audio:
        fname = f"aud_{datetime.now().strftime('%m%d_%H%M%S')}.webm"
        audio.save(os.path.join(basedir, 'static/uploads', fname))
        aud_path = f"uploads/{fname}"
    
    srv_id = None
    if recipient_id == 'manager':
        srv_id = 0 
    elif recipient_id and recipient_id != 'all':
        srv_id = int(recipient_id)
        
    db.session.add(Message(
        company_id=get_company_id(),
        server_id=srv_id,
        sender_id=sender_id,
        content=content,
        image_path=img_path,
        audio_path=aud_path
    ))
    db.session.commit()
    return redirect(request.referrer or url_for('home'))

@app.route('/api/check_messages')
def api_check_messages():
    last_id = int(request.args.get('last_id', 0))
    uid = session.get('user_id')
    role = session.get('role')
    
    # Filtre selon qui écoute
    cid = get_company_id()
    if role == 'manager':
        # Le manager écoute ce qui lui est envoyé par tout le monde dans sa société
        msgs = Message.query.filter(Message.id > last_id, Message.company_id == cid, Message.server_id == 0).all()
    elif role == 'server':
        # Le serveur écoute ce qui lui est envoyé perso ou au groupe dans sa société
        msgs = Message.query.filter(Message.id > last_id, Message.company_id == cid, (Message.server_id == uid) | (Message.server_id == None)).all()
    else:
        return jsonify(new_messages=[])

    return jsonify(new_messages=[{'id': m.id, 'content': m.content} for m in msgs])

@app.route('/api/mark_read', methods=['POST'])
def api_mark_read():
    """Marquer un message ou tous les messages comme lu(s)"""
    cid = get_company_id()
    msg_id = request.form.get('message_id')
    if msg_id:
        msg = Message.query.filter_by(id=msg_id, company_id=cid).first()
        if msg:
            msg.is_read = True
            db.session.commit()
    else:
        # Marquer tous les messages non-lus comme lus
        uid = session.get('user_id')
        role = session.get('role')
        if role == 'manager':
            Message.query.filter_by(company_id=cid, server_id=0, is_read=False).update({Message.is_read: True})
        elif uid:
            Message.query.filter(
                Message.company_id == cid,
                ((Message.server_id == uid) | (Message.server_id == None)),
                Message.is_read == False
            ).update({Message.is_read: True}, synchronize_session='fetch')
        db.session.commit()
    return jsonify(success=True)

@app.route('/hebergement/maintenance', methods=['GET', 'POST'])
def hbg_maintenance():
    """Vue maintenance technique pour l'hébergement"""
    if not (is_manager() or is_hbg_any()): return redirect(url_for('role_selection'))
    cid = get_company_id()
    
    if request.method == 'POST' and is_hbg_responsable():
        name = request.form.get('name')
        if name:
            t = HbgTable(company_id=cid, name=f"🔧 {name}", table_type='followup')
            db.session.add(t)
            db.session.flush()
            # Colonnes par défaut de maintenance
            for i, label in enumerate(['Description du problème', 'Priorité', 'Statut', 'Assigné à']):
                db.session.add(HbgColumn(table_id=t.id, label=label, order=i))
            db.session.commit()
            flash(f"Fiche maintenance '{name}' créée avec colonnes par défaut.", "success")
            return redirect(url_for('hbg_view_table', table_id=t.id))
    
    # Lister les tableaux de type maintenance/followup
    tables = HbgTable.query.filter_by(company_id=cid, table_type='followup').order_by(HbgTable.created_at.desc()).all()
    return render_template('hbg_maintenance.html', tables=tables, can_manage=is_hbg_responsable())

@app.route('/dashboard/manager/voice', methods=['POST'])
def voice_broadcast():
    audio = request.files.get('audio')
    if audio:
        fname = f"vcl_{datetime.now().strftime('%m%d_%H%M%S')}.webm"
        audio.save(os.path.join(basedir, 'static/uploads', fname))
        db.session.add(Message(
            company_id=get_company_id(),
            server_id=None, # All
            sender_id=0, # Manager
            content="Message vocal (Diffusion)",
            audio_path=f"uploads/{fname}"
        ))
        db.session.commit()
        return jsonify(success=True)
    return jsonify(success=False)

@app.route('/dashboard/manager/global')
def global_view():
    if not is_manager(): return redirect(url_for('login'))
    cid = get_company_id()
    servers = Server.query.filter_by(company_id=cid).all(); tday = date.today(); tday_str = str(tday)
    matrix = {(st.server_id, st.task_id): st.is_done for st in TaskStatus.query.filter_by(company_id=cid, date_str=tday_str).all()}
    t_by_p = {"Avant le service": [], "Pendant le service": [], "Après le service": []}
    for t in Task.query.filter_by(company_id=cid).all(): t_by_p[t.phase].append(t)
    return render_template('responsable_global_view.html', servers=servers, tasks_by_phase=t_by_p, status_matrix=matrix, today=tday)
@app.route('/dashboard/manager/events', methods=['GET', 'POST'])
def manage_events():
    if not is_manager(): return redirect(url_for('login'))
    cid = get_company_id()
    section = request.args.get('section', 'restauration')
    
    if request.method == 'POST':
        action = request.form.get('action')
        if action == 'create':
            ev = Event(
                company_id=cid,
                title=request.form.get('title'),
                event_date=request.form.get('event_date'),
                event_time=request.form.get('event_time', '12:00'),
                guest_count=int(request.form.get('guest_count') or 0),
                menu_details=request.form.get('menu_details', ''),
                equipment_details=request.form.get('equipment_details', ''),
                notes=request.form.get('notes', ''),
                department=section
            )
            db.session.add(ev)
            db.session.flush()
            
            task_count = int(request.form.get('task_count', 0))
            for i in range(task_count):
                desc = request.form.get(f'task_desc_{i}')
                sid = request.form.get(f'task_server_{i}')
                if desc and sid:
                    db.session.add(EventTask(event_id=ev.id, server_id=int(sid), description=desc))
            db.session.commit()
            flash('Fiche événement créée avec succès.', 'success')
        
        elif action == 'archive':
            ev = Event.query.filter_by(id=request.form.get('event_id'), company_id=cid).first()
            if ev: 
                ev.is_archived = True
                db.session.commit()
                flash('Événement archivé.', 'info')
        
        elif action == 'delete':
            ev = Event.query.filter_by(id=request.form.get('event_id'), company_id=cid).first()
            if ev:
                EventTask.query.filter_by(event_id=ev.id).delete()
                db.session.delete(ev)
                db.session.commit()
                flash('Événement supprimé.', 'warning')
        
        return redirect(url_for('manage_events', section=section))
    
    active_events = Event.query.filter(Event.company_id == cid, Event.is_archived == False, (Event.department == section) | (Event.department == None)).order_by(Event.event_date.desc()).all()
    archived_events = Event.query.filter(Event.company_id == cid, Event.is_archived == True, (Event.department == section) | (Event.department == None)).order_by(Event.event_date.desc()).all()
    
    servers = Server.query.filter_by(department=section).all()
    
    return render_template('manage_events.html', 
                         active_events=active_events, 
                         archived_events=archived_events, 
                         servers=servers,
                         current_section=section)

@app.route('/api/toggle_event_task/<int:task_id>', methods=['POST'])
def toggle_event_task(task_id):
    et = EventTask.query.get(task_id)
    if et:
        et.is_done = not et.is_done
        db.session.commit()
        return jsonify(success=True, is_done=et.is_done)
    return jsonify(success=False)

@app.route('/dashboard/manager/hard-reset', methods=['POST'])
def hard_reset():
    if not is_manager(): return redirect(url_for('login'))
    cid = get_company_id()
    # Suppression de toutes les données de la société pour repartir à zéro
    db.session.query(SaleRecord).filter(SaleRecord.shift.has(Shift.company_id == cid)).delete(synchronize_session=False)
    db.session.query(EventTask).filter(EventTask.event.has(Event.company_id == cid)).delete(synchronize_session=False)
    db.session.query(Event).filter_by(company_id=cid).delete()
    db.session.query(ShiftStock).filter(ShiftStock.item.has(StockItem.company_id == cid)).delete(synchronize_session=False)
    db.session.query(StockTransaction).filter_by(company_id=cid).delete()
    db.session.query(TaskStatus).filter_by(company_id=cid).delete()
    db.session.query(Shift).filter_by(company_id=cid).delete()
    db.session.query(Message).filter_by(company_id=cid).delete()
    db.session.query(WeeklyPlan).filter_by(company_id=cid).delete()
    db.session.commit()
    flash("Toutes les données de votre entreprise ont été réinitialisées.", "warning")
    return redirect(url_for('manager_dashboard'))

@app.route('/api/mark_read', methods=['POST'])
def mark_read():
    cid = get_company_id()
    uid = session.get('user_id')
    role = session.get('role')
    if role == 'manager':
        Message.query.filter_by(company_id=cid, server_id=0, is_read=False).update({Message.is_read: True})
    else:
        Message.query.filter_by(company_id=cid, server_id=uid, is_read=False).update({Message.is_read: True})
    db.session.commit()
    return jsonify(success=True)

@app.route('/send_message', methods=['POST'])
def send_message():
    if not (session.get('user_id') or session.get('role') == 'manager'): return redirect(url_for('login'))
    cid = get_company_id()
    sid = request.form.get('server_id')
    db.session.add(Message(
        company_id=cid,
        server_id=None if sid=='all' else int(sid),
        content=request.form.get('content')
    ))
    db.session.commit()
    return redirect(request.referrer or url_for('global_view'))

@app.route('/manager/reports')
def view_reports():
    if not is_manager(): return redirect(url_for('login'))
    cid = get_company_id()
    reports = []
    rdir = os.path.join(basedir, 'static/reports')
    if os.path.exists(rdir):
        for f in sorted(os.listdir(rdir), reverse=True):
            if f.startswith('rapport_'):
                try:
                    sh_id = int(f.replace('rapport_','').replace('.pdf',''))
                    sh = Shift.query.get(sh_id)
                    # Filtrer les rapports par société du shift
                    if sh and sh.company_id == cid:
                         reports.append({'filename': f, 'shift': sh, 'server': Server.query.get(sh.server_id)})
                except: continue
    return render_template('reports.html', reports=reports)

# --- Vue événements côté serveur ---
@app.route('/dashboard/server/events')
def server_events():
    uid = session.get('user_id')
    s = Server.query.get(uid)
    if not s: return redirect(url_for('logout'))
    # Événements actifs ayant des tâches pour ce serveur dans sa société
    my_tasks = EventTask.query.join(Event).filter(EventTask.server_id == uid, Event.company_id == s.company_id).all()
    event_ids = list(set(t.event_id for t in my_tasks))
    events = Event.query.filter(Event.id.in_(event_ids), Event.is_archived == False, Event.company_id == s.company_id).all() if event_ids else []
    return render_template('server_events.html', events=events, my_tasks=my_tasks, server_id=uid)

# --- TOGGLE TASK (Serveur) ---
@app.route('/toggle_task/<int:task_id>', methods=['POST'])
def toggle_task(task_id):
    uid = session.get('user_id'); cid = get_company_id()
    ts = str(date.today())
    st = TaskStatus.query.filter_by(company_id=cid, server_id=uid, task_id=task_id, date_str=ts).first()
    if st:
        st.is_done = not st.is_done
        st.completion_time = datetime.now() if st.is_done else None
        db.session.commit()
        return jsonify(success=True)
    return jsonify(success=False), 404

# --- RAPPORT HEBDOMADAIRE AUTOMATIQUE ---
def run_weekly_report_logic(cid):
    """Génère un PDF récapitulatif hebdomadaire et l'envoie par email si configuré"""
    if not FPDF:
        return False, "Librarie PDF manquante."
    try:
        co = Company.query.get(cid)
        if not co: return False, "Société introuvable"
        
        tday = date.today()
        iso_year, iso_week, _ = tday.isocalendar()
        start_week = tday - timedelta(days=tday.weekday())
        
        pdf = FPDF(orientation='L', unit='mm', format='A4')
        pdf.set_auto_page_break(auto=True, margin=15)
        
        # ===== PAGE 1: PLANNING HEBDOMADAIRE =====
        pdf.add_page()
        pdf.set_fill_color(15, 23, 42)
        pdf.set_text_color(255, 255, 255)
        pdf.set_font("Arial", 'B', 16)
        pdf.cell(280, 12, txt=clean_str(f"RAPPORT HEBDOMADAIRE — {co.name}"), ln=True, align='C', fill=True)
        pdf.set_font("Arial", '', 9)
        pdf.cell(280, 8, txt=clean_str(f"Semaine {iso_week} / {iso_year} — Généré le {tday.strftime('%d/%m/%Y')}"), ln=True, align='C', fill=True)
        pdf.ln(8)
        
        # Planning par serveur
        pdf.set_text_color(0, 0, 0)
        pdf.set_font("Arial", 'B', 13)
        pdf.cell(280, 10, txt="PLANNING DE LA SEMAINE", ln=True)
        pdf.ln(3)
        
        servers = Server.query.filter_by(company_id=cid).all()
        days_names = ["Lun", "Mar", "Mer", "Jeu", "Ven", "Sam", "Dim"]
        
        # En-tête du tableau
        pdf.set_font("Arial", 'B', 8)
        pdf.set_fill_color(241, 245, 249)
        pdf.cell(60, 8, "Collaborateur", 1, 0, 'C', True)
        for d in days_names:
            pdf.cell(31, 8, d, 1, 0, 'C', True)
        pdf.ln()
        
        pdf.set_font("Arial", '', 8)
        for srv in servers:
            pdf.cell(60, 7, clean_str(srv.name.capitalize()), 1, 0, 'L')
            for day_i in range(7):
                plan = WeeklyPlan.query.filter_by(company_id=cid, server_id=srv.id, year=iso_year, week=iso_week, day_of_week=day_i).first()
                if plan:
                    if plan.is_off:
                        pdf.set_fill_color(254, 226, 226)
                        pdf.cell(31, 7, "OFF", 1, 0, 'C', True)
                        pdf.set_fill_color(255, 255, 255)
                    else:
                        txt = f"{plan.start_time_str}-{plan.end_time_str}"
                        pdf.cell(31, 7, txt, 1, 0, 'C')
                else:
                    pdf.set_fill_color(243, 244, 246)
                    pdf.cell(31, 7, "-", 1, 0, 'C', True)
                    pdf.set_fill_color(255, 255, 255)
            pdf.ln()
        
        # ===== PAGE 2: ÉTAT DES STOCKS =====
        pdf.add_page()
        pdf.set_font("Arial", 'B', 13)
        pdf.cell(280, 10, txt="ETAT DES STOCKS", ln=True)
        pdf.ln(3)
        
        stock_items = StockItem.query.filter_by(company_id=cid).all()
        if stock_items:
            pdf.set_font("Arial", 'B', 9)
            pdf.set_fill_color(241, 245, 249)
            pdf.cell(80, 8, "Produit", 1, 0, 'L', True)
            pdf.cell(35, 8, "Stock Actuel", 1, 0, 'C', True)
            pdf.cell(35, 8, "Ventes Hebdo", 1, 0, 'C', True)
            pdf.cell(40, 8, "Seuil Min", 1, 0, 'C', True)
            pdf.cell(50, 8, "Statut", 1, 0, 'C', True)
            pdf.ln()
            
            pdf.set_font("Arial", '', 9)
            for item in stock_items:
                # Agrégation des ventes hebdo
                weekly_sales = db.session.query(db.func.sum(ShiftStock.sales)).filter(
                    ShiftStock.item_id == item.id,
                    ShiftStock.shift_id.in_(db.session.query(Shift.id).filter(
                        Shift.company_id == cid, 
                        Shift.date_str >= str(start_week)
                    ))
                ).scalar() or 0

                pdf.cell(80, 7, clean_str(item.name), 1, 0, 'L')
                pdf.cell(35, 7, str(item.current_quantity), 1, 0, 'C')
                pdf.cell(35, 7, str(weekly_sales), 1, 0, 'C') # Ventes de la semaine
                pdf.cell(40, 7, str(item.min_threshold), 1, 0, 'C')
                
                if item.current_quantity <= item.min_threshold:
                    pdf.set_fill_color(254, 226, 226)
                    pdf.cell(50, 7, "ALERTE", 1, 0, 'C', True)
                    pdf.set_fill_color(255, 255, 255)
                else:
                    pdf.set_fill_color(220, 252, 231)
                    pdf.cell(50, 7, "OK", 1, 0, 'C', True)
                    pdf.set_fill_color(255, 255, 255)
                pdf.ln()
            
            # Ligne de TOTAL pour les stocks
            total_qty = sum(item.current_quantity for item in stock_items)
            pdf.set_font("Arial", 'B', 9)
            pdf.set_fill_color(241, 245, 249)
            pdf.cell(100, 9, " TOTAL", 1, 0, 'L', True)
            pdf.cell(50, 9, str(total_qty), 1, 0, 'C', True)
            pdf.cell(130, 9, "", 1, 0, 'C', True)
            pdf.ln()
        else:
            pdf.set_font("Arial", 'I', 10)
            pdf.cell(190, 10, "Aucun article en stock.", ln=True)
        
        # ===== PAGE 3: CHECK-LISTS =====
        pdf.add_page()
        pdf.set_font("Arial", 'B', 13)
        pdf.cell(280, 10, txt="LISTE DES TACHES & CHECKLISTS", ln=True)
        pdf.ln(3)
        
        tasks = Task.query.filter_by(company_id=cid).order_by(Task.phase).all()
        current_phase = ""
        
        # En-tête tableau stats
        pdf.set_font("Arial", 'B', 9)
        pdf.set_fill_color(241, 245, 249)
        pdf.cell(140, 8, "Tâche", 1, 0, 'L', True)
        pdf.cell(30, 8, "Heure", 1, 0, 'C', True)
        pdf.cell(30, 8, "Effectif", 1, 0, 'C', True)
        pdf.cell(80, 8, "Taux de réalisation (Semaine)", 1, 0, 'C', True)
        pdf.ln()
        
        # Calcul des dates de la semaine
        start_monday_str = str(tday - timedelta(days=tday.weekday()))
        
        for task in tasks:
            if task.phase != current_phase:
                current_phase = task.phase
                pdf.set_font("Arial", 'B', 10)
                pdf.set_fill_color(241, 245, 249)
                pdf.cell(280, 8, clean_str(current_phase), 1, 1, 'L', True)
            
            # Calcul du taux de réalisation pour cette tâche cette semaine
            total_days_planned = 7 # Simplification
            done_count = TaskStatus.query.filter(
                TaskStatus.task_id == task.id, 
                TaskStatus.is_done == True,
                TaskStatus.date_str >= start_monday_str
            ).count()
            
            rate = int((done_count / 7) * 100) # Pourcentage sur 7 jours
            
            pdf.set_font("Arial", '', 9)
            pdf.cell(140, 7, clean_str(f"  {task.name}"), 1, 0, 'L')
            pdf.cell(30, 7, task.scheduled_time, 1, 0, 'C')
            pdf.cell(30, 7, f"{task.required_people}p.", 1, 0, 'C')
            
            # Barre de progression visuelle simple
            pdf.set_fill_color(243, 244, 246)
            pdf.cell(80, 7, f"{rate}% ({done_count}/7j)", 1, 0, 'C', True)
            pdf.set_fill_color(255, 255, 255) # Reset fill default
            pdf.ln()

        # ===== PAGE 4: JOURNAL D'ACTIVITÉ (TRAÇABILITÉ) =====
        pdf.add_page()
        pdf.set_font("Arial", 'B', 13)
        pdf.cell(280, 10, txt="JOURNAL D'ACTIVITE (TRACABILITE)", ln=True)
        pdf.ln(3)
        
        # Récupérer les shifts de la semaine pour l'historique
        recent_shifts = Shift.query.filter(
            Shift.company_id == cid, 
            Shift.date_str >= str(start_week)
        ).order_by(Shift.id.desc()).all()
        
        pdf.set_font("Arial", 'B', 9)
        pdf.set_fill_color(241, 245, 249)
        pdf.cell(50, 8, "Date", 1, 0, 'C', True)
        pdf.cell(70, 8, "Collaborateur", 1, 0, 'C', True)
        pdf.cell(40, 8, "Debut", 1, 0, 'C', True)
        pdf.cell(40, 8, "Fin", 1, 0, 'C', True)
        pdf.cell(40, 8, "Retard", 1, 0, 'C', True)
        pdf.cell(40, 8, "H. Sup", 1, 0, 'C', True)
        pdf.ln()
        
        pdf.set_font("Arial", '', 8)
        for sh in recent_shifts:
            srv = Server.query.get(sh.server_id)
            name = srv.name if srv else "N/A"
            start_t = sh.actual_start_time.strftime('%H:%M') if sh.actual_start_time else "--:--"
            end_t = sh.actual_end_time.strftime('%H:%M') if sh.actual_end_time else "Non clos"
            
            pdf.cell(50, 7, sh.date_str, 1, 0, 'C')
            pdf.cell(70, 7, clean_str(name.capitalize()), 1, 0, 'C')
            pdf.cell(40, 7, start_t, 1, 0, 'C')
            pdf.cell(40, 7, end_t, 1, 0, 'C')
            pdf.cell(40, 7, f"{sh.lateness_minutes} min", 1, 0, 'C')
            pdf.cell(40, 7, f"{sh.overtime_minutes} min", 1, 0, 'C')
            pdf.ln()
        
        # Sauvegarder le PDF
        fname = f"rapport_hebdo_S{iso_week}_{co.name.replace(' ', '_')}.pdf"
        fpath = os.path.join(basedir, 'static', 'reports', fname)
        pdf.output(fpath)
        
        # ===== PACKAGING ZIP DES RAPPORTS INDIVIDUELS =====
        import zipfile
        zip_name = f"rapports_individuels_S{iso_week}_{co.name.replace(' ', '_')}.zip"
        zip_path = os.path.join(basedir, 'static', 'reports', zip_name)
        
        with zipfile.ZipFile(zip_path, 'w') as zipf:
            for sh in recent_shifts:
                # Regénérer ou retrouver le PDF du shift
                fname_sh = generate_pdf(sh.id) # Assuming generate_pdf exists and returns filename
                if fname_sh:
                    fpath_sh = os.path.join(basedir, 'static', 'reports', fname_sh)
                    if os.path.exists(fpath_sh):
                        zipf.write(fpath_sh, arcname=fname_sh)
        
        # Envoi email si configuré (avec le rapport consolidé ET le ZIP)
        email_sent, email_msg = send_weekly_email(cid, pdf_path=fpath, zip_path=zip_path)
        
        if email_sent:
            co.last_report_sent = tday
            db.session.commit()
            
        return True, jsonify(
            success=True, 
            pdf_url=f"/static/reports/{fname}",
            zip_url=f"/static/reports/{zip_name}",
            email_sent=email_sent,
            message=f"Rapport S{iso_week} et ZIP générés avec succès."
        )
    except Exception as e:
        traceback.print_exc()
        return False, str(e)

@app.route('/api/weekly_report', methods=['GET', 'POST'])
def api_weekly_report():
    if not is_manager(): return jsonify(success=False, error="Accès interdit"), 403
    cid = get_company_id()
    success, result = run_weekly_report_logic(cid)
    if success:
        return result
    else:
        return jsonify(success=False, error=result), 500

# --- PARAMÈTRES UTILISATEUR ---
@app.route('/settings', methods=['GET', 'POST'])
def user_settings():
    cid = get_company_id()
    role = session.get('role')
    uid = session.get('user_id')
    if not uid: return redirect(url_for('role_selection'))
    
    if role == 'manager':
        user = Manager.query.filter_by(id=uid, company_id=cid).first()
    else:
        user = Server.query.filter_by(id=uid, company_id=cid).first()
    
    if not user: return redirect(url_for('logout'))
    
    if request.method == 'POST':
        action = request.form.get('action')
        
        if action == 'change_password':
            current_pw = request.form.get('current_password')
            new_pw = request.form.get('new_password')
            confirm_pw = request.form.get('confirm_password')
            
            if not check_password_hash(user.password_hash or '', current_pw):
                flash("Mot de passe actuel incorrect.", "danger")
            elif new_pw != confirm_pw:
                flash("Les mots de passe ne correspondent pas.", "danger")
            elif len(new_pw) < 4:
                flash("Le mot de passe doit faire au moins 4 caractères.", "danger")
            else:
                user.password_hash = generate_password_hash(new_pw)
                db.session.commit()
                flash("Mot de passe modifié avec succès !", "success")
        
        elif action == 'update_profile':
            if role == 'manager':
                new_email = request.form.get('email')
                if new_email:
                    user.email = new_email
                    db.session.commit()
                    flash("Profil mis à jour.", "success")
            else:
                new_name = request.form.get('name')
                if new_name:
                    user.name = new_name
                    db.session.commit()
                    session['user_name'] = new_name
                    flash("Profil mis à jour.", "success")
        
        return redirect(url_for('user_settings'))
    
    return render_template('settings.html', user=user, role=role)

# --- ERROR HANDLERS ---
@app.errorhandler(404)
def page_not_found(e):
    return render_template('error.html', code=404, message="Page introuvable."), 404

@app.errorhandler(500)
def internal_error(e):
    db.session.rollback()
    return render_template('error.html', code=500, message="Erreur interne du serveur."), 500

@app.route('/logout')

# --- API CRON : VÉRIFICATION DES DONNÉES MANQUANTES ---
@app.route('/api/cron/check_data', methods=['POST'])
def cron_check_data():
    data = request.get_json() or {}
    # Sécurité simple pour éviter les appels externes non autorisés
    if data.get('key') != "SUPERVISION_CRON_SECRET_2026":
        return jsonify(success=False, error="Clé invalide"), 403
    
    tday = date.today()
    tday_str = str(tday)
    now = datetime.now()
    cur_time = now.strftime("%H:%M")
    
    notifications_sent = 0
    
    # 1. Vérifier les tâches en retard (non faites)
    all_servers = Server.query.all()
    for srv in all_servers:
        # Tâches du département de l'employé
        tasks = Task.query.filter_by(company_id=srv.company_id, department=srv.department).all()
        overdue_names = []
        for t in tasks:
            if t.scheduled_time and t.scheduled_time < cur_time:
                st = TaskStatus.query.filter_by(server_id=srv.id, task_id=t.id, date_str=tday_str).first()
                if not st or not st.is_done:
                    overdue_names.append(t.name)
        
        if overdue_names:
            # Notifier le serveur (In-app)
            msg_srv = f"⚠️ RAPPEL : Vous avez {len(overdue_names)} tâches en retard : {', '.join(overdue_names[:3])}"
            db.session.add(Message(company_id=srv.company_id, server_id=srv.id, sender_id=0, content=msg_srv))
            
            # Notifier le responsable (In-app)
            msg_mgr = f"🚨 RETARD ({srv.name}) : {len(overdue_names)} tâches non faites à {cur_time}."
            db.session.add(Message(company_id=srv.company_id, server_id=0, sender_id=srv.id, content=msg_mgr))
            notifications_sent += 2

        # 1b. Détecter stocks non saisis (si c'est presque la fin du shift)
        iso_year, iso_week, day_idx = tday.isocalendar()
        sh_active = Shift.query.filter_by(server_id=srv.id, actual_end_time=None, date_str=tday_str).first()
        if sh_active:
            # Si le shift est en cours, on vérifie si des ventes ont été enregistrées ou si le stock a été sauvé
            saved_stocks = ShiftStock.query.filter_by(shift_id=sh_active.id).count()
            if saved_stocks == 0 and cur_time > "15:00": # Exemple : rappel après 15h
                 msg = f"📦 Rappel : Pensez à commencer à saisir vos STOCKS ({srv.name})."
                 db.session.add(Message(company_id=srv.company_id, server_id=srv.id, sender_id=0, content=msg))
                 notifications_sent += 1

    # 2. Vérifier les shifts non clôturés alors que l'heure de fin est dépassée
    open_shifts = Shift.query.filter_by(actual_end_time=None, date_str=tday_str).all()
    for sh in open_shifts:
        srv = Server.query.get(sh.server_id)
        # Check planning
        iso_year, iso_week, day_idx = tday.isocalendar()
        p = WeeklyPlan.query.filter_by(server_id=srv.id, year=iso_year, week=iso_week, day_of_week=day_idx-1).first()
        if p and p.end_time_str < cur_time:
            # Notifier de clôturer le service
            msg = f"🔔 N'oubliez pas de CLOTURER votre service et remplir les STOCKS ({srv.name})."
            db.session.add(Message(company_id=sh.company_id, server_id=srv.id, sender_id=0, content=msg))
            notifications_sent += 1

    # 3. TRIGGER RAPPORT HEBDOMADAIRE (Lundi)
    if tday.weekday() == 0:
        all_cos = Company.query.all()
        for co in all_cos:
            if not co.last_report_sent or co.last_report_sent < tday:
                success, res = run_weekly_report_logic(co.id)
                if success: notifications_sent += 1

    db.session.commit()
    return jsonify(success=True, notifications_sent=notifications_sent)

@app.route('/debug/planning')
def debug_planning():
    if not is_manager(): return "Accès réservé au manager", 403
    cid = get_company_id()
    tday = date.today()
    iy, iw, idx = tday.isocalendar()
    plans = WeeklyPlan.query.filter_by(company_id=cid).all()
    res = f"Date: {tday} | ISO: {iy} W{iw}<br><br>"
    res += f"<b>Plans en base pour cette société ({cid}):</b><br>"
    if not plans:
        res += "Aucun planning trouvé en base."
    for p in plans:
        res += f"SrvID: {p.server_id} | Y: {p.year} | W: {p.week} | Day: {p.day_of_week} | {p.start_time_str}-{p.end_time_str}<br>"
    return res

def logout(): session.clear(); return redirect(url_for('home'))

# --- INITIALISATION SÉCURISÉE ---
def init_database():
    """Initialisation défensive — ne crash jamais, même si la DB a déjà les colonnes."""
    try:
        db.create_all()
        
        # Créer les dossiers nécessaires
        for folder in ['static/reports', 'static/audio', 'static/uploads', 'instance', 'templates']:
            os.makedirs(os.path.join(basedir, folder), exist_ok=True)
        
        # Migration multi-sociétés (silencieuse si colonnes déjà existantes)
        migrations = [
            ('server', 'company_id', 'INTEGER DEFAULT 1'),
            ('manager', 'company_id', 'INTEGER DEFAULT 1'),
            ('weekly_plan', 'company_id', 'INTEGER DEFAULT 1'),
            ('shift', 'company_id', 'INTEGER DEFAULT 1'),
            ('task', 'company_id', 'INTEGER DEFAULT 1'),
            ('task_status', 'company_id', 'INTEGER DEFAULT 1'),
            ('stock_item', 'company_id', 'INTEGER DEFAULT 1'),
            ('stock_transaction', 'company_id', 'INTEGER DEFAULT 1'),
            ('shift_stock', 'company_id', 'INTEGER DEFAULT 1'),
            ('message', 'company_id', 'INTEGER DEFAULT 1'),
            ('email_config', 'company_id', 'INTEGER DEFAULT 1'),
            ('event', 'company_id', 'INTEGER DEFAULT 1'),
            ('event_task', 'company_id', 'INTEGER DEFAULT 1'),
            ('hbg_inspection', 'company_id', 'INTEGER DEFAULT 1'),
            ('hbg_follow_up', 'company_id', 'INTEGER DEFAULT 1'),
            ('hbg_table', 'company_id', 'INTEGER DEFAULT 1'),
            ('hbg_column', 'company_id', 'INTEGER DEFAULT 1'),
            ('hbg_row', 'company_id', 'INTEGER DEFAULT 1'),
            ('sale_record', 'company_id', 'INTEGER DEFAULT 1'),
            ('shift_stock', 'company_id', 'INTEGER DEFAULT 1'),
            ('task', 'assigned_server_id', 'INTEGER'),
            ('company', 'code', 'TEXT'),
            ('company', 'last_report_sent', 'DATE'),
            ('message', 'sender_id', 'INTEGER DEFAULT 0'),
            ('message', 'is_read', 'BOOLEAN DEFAULT 0'),
            ('manager', 'username', 'TEXT DEFAULT "admin"'),
            ('manager', 'email', 'TEXT'),
            ('server', 'department', 'TEXT DEFAULT "restauration"'),
            ('server', 'hbg_role', 'TEXT DEFAULT "none"'),
            ('task', 'department', 'TEXT DEFAULT "restauration"'),
            ('stock_item', 'department', 'TEXT DEFAULT "restauration"'),
            ('event', 'department', 'TEXT DEFAULT "restauration"'),
        ]
        
        for tbl, col, col_type in migrations:
            try:
                db.session.execute(text(f"ALTER TABLE {tbl} ADD COLUMN {col} {col_type}"))
                db.session.commit()
            except:
                db.session.rollback()
        
        # Société par défaut
        if not Company.query.get(1):
            db.session.add(Company(id=1, name="Entreprise Melek", code="MELEK2026"))
            db.session.commit()
        else:
            co1 = Company.query.get(1)
            if not co1.code:
                co1.code = "MELEK2026"
                db.session.commit()
        
        # Nettoyage et Migration de données
        try:
            Server.query.filter((Server.department == None) | (Server.department == '')).update({Server.department: 'restauration'})
            Server.query.filter(Server.hbg_role == None).update({Server.hbg_role: 'none'})
            for model in [Server, Manager, WeeklyPlan, Shift, Task, TaskStatus, StockItem, Event, HbgInspection, HbgFollowUp, HbgTable, ShiftStock, Message]:
                model.query.filter(model.company_id == None).update({model.company_id: 1})
            
            # Réparation Planning (Année/Semaine manquante)
            ty, tw, _ = date.today().isocalendar()
            WeeklyPlan.query.filter((WeeklyPlan.year == None) | (WeeklyPlan.year == 0)).update({WeeklyPlan.year: ty, WeeklyPlan.week: tw})
            
            db.session.commit()
        except:
            db.session.rollback()
        
        # Manager par défaut
        if not Manager.query.filter_by(company_id=1).first():
            db.session.add(Manager(company_id=1, username='admin', password_hash=generate_password_hash('melek2026')))
        
        # Serveurs par défaut
        for n in ["ali", "meriem", "mohammedbs", "mohammed2", "ikram"]:
            if not Server.query.filter_by(name=n, company_id=1).first():
                db.session.add(Server(name=n, department='restauration', company_id=1))
        
        if not Server.query.filter_by(name='melek_hbg', company_id=1).first():
            db.session.add(Server(name='melek_hbg', department='hebergement', hbg_role='responsable', company_id=1))
        if not Server.query.filter_by(name='agent_hbg', company_id=1).first():
            db.session.add(Server(name='agent_hbg', department='hebergement', hbg_role='superviseur', company_id=1))
        
        db.session.commit()
        
        # Tâches par défaut
        if Task.query.count() < 26:
            Task.query.delete()
            tasks_data = [
                ("Avant le service", "Nettoyage et désinfection des tables", "08:15", 2),
                ("Avant le service", "Nettoyage des consoles, buffets et comptoirs", "08:30", 1),
                ("Avant le service", "Nettoyage des chaises (dessus et pieds)", "08:45", 2),
                ("Avant le service", "Nettoyage du sol (balayage + lavage)", "09:00", 2),
                ("Avant le service", "Vérification de la propreté des menus", "09:15", 1),
                ("Avant le service", "Vérification de l'éclairage et de la musique", "09:20", 1),
                ("Avant le service", "Préparation du snack bar (vitrine propre)", "09:30", 1),
                ("Avant le service", "Vérification des stocks (boissons, snacks)", "09:40", 1),
                ("Avant le service", "Polissage des assiettes", "09:50", 2),
                ("Avant le service", "Polissage des couverts", "10:00", 2),
                ("Avant le service", "Polissage des verres", "10:15", 2),
                ("Avant le service", "Rangement du matériel propre", "10:30", 1),
                ("Pendant le service", "Nettoyage et rangement terrasse", "12:00", 2),
                ("Pendant le service", "Préparer les plateaux de sécurité", "12:15", 1),
                ("Pendant le service", "Mise en place des tables des clients", "12:30", 2),
                ("Pendant le service", "Service du Directeur Général", "13:00", 1),
                ("Pendant le service", "Ventes des produits", "13:30", 3),
                ("Pendant le service", "Débarrassage des tables", "14:00", 2),
                ("Pendant le service", "Service clients", "14:30", 3),
                ("Pendant le service", "Changement des cendriers", "15:00", 1),
                ("Pendant le service", "Surveillance propreté sol", "15:30", 1),
                ("Après le service", "Nettoyage du comptoir", "18:00", 1),
                ("Après le service", "Nettoyage des machines (café, jus, etc.)", "18:30", 1),
                ("Après le service", "Nettoyage de la vitrine réfrigérée", "18:45", 1),
                ("Après le service", "Nettoyage des étagères et présentoirs", "19:00", 1),
                ("Après le service", "Désinfection poignées, boutons et caisses", "19:15", 1),
            ]
            for phase, name, t, people in tasks_data:
                db.session.add(Task(company_id=1, phase=phase, name=name, scheduled_time=t, required_people=people))
        db.session.commit()
        print("[OK] Base de données initialisée avec succès.")
    except Exception as e:
        print(f"[ERREUR INIT] {e}")
        traceback.print_exc()
        db.session.rollback()

with app.app_context():
    init_database()

if __name__ == '__main__':
    app.run(debug=True, port=int(os.environ.get('PORT', 5002)), host='0.0.0.0')
