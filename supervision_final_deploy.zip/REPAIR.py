import os
import sys
import traceback

print("="*40)
print("   SUPERVISION PRO - SCRIPT DE RÉPARATION")
print("="*40)

# 1. Vérifier les dépendances
print("\n[1/4] Vérification des modules Python...")
try:
    import flask
    import flask_sqlalchemy
    from fpdf import FPDF
    print("  - Flask: OK")
    print("  - Flask-SQLAlchemy: OK")
    print("  - FPDF (fpdf2): OK")
except ImportError as e:
    print(f"  !!! Erreur : Module manquant : {e}")
    print("  Tentative d'installation...")
    os.system("pip install --user flask flask-sqlalchemy fpdf2 werkzeug")

# 2. Vérifier l'import de l'application
print("\n[2/4] Test de chargement de l'application...")
try:
    from app import app, db, init_database
    print("  - Import 'app': OK")
except Exception as e:
    print(f"  !!! CRASH au chargement : {e}")
    traceback.print_exc()
    sys.exit(1)

# 3. Initialisation de la base de données
print("\n[3/4] Mise à jour de la base de données...")
try:
    with app.app_context():
        init_database()
    print("  - Base de données: INITIALISÉE / MISE À JOUR")
except Exception as e:
    print(f"  !!! Erreur Database : {e}")
    traceback.print_exc()

# 4. Vérification finale du mode WSGI
print("\n[4/4] Vérification du point d'entrée...")
if os.path.exists("app.py"):
    print("  - app.py présent: OK")
else:
    print("  !!! ALERTE : app.py manquant dans le dossier courant !")

print("\n" + "="*40)
print(" RÉPARATION TERMINÉE !")
print(" Veuillez cliquer sur RELOAD dans l'onglet WEB")
print("="*40)
